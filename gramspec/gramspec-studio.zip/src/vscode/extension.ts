import * as vscode from "vscode";

import {
  getSelectorRejectionText,
  getSyntheticGraphRenderText,
} from "./adapter.js";

export const SHOW_SYNTHETIC_GRAPH_COMMAND =
  "gramspecStudio.showSyntheticGraph" as const;
export const SHOW_SELECTOR_REJECTION_COMMAND =
  "gramspecStudio.showSelectorRejection" as const;

async function showText(content: string): Promise<string> {
  const document = await vscode.workspace.openTextDocument({
    content,
    language: "plaintext",
  });
  await vscode.window.showTextDocument(document, { preview: false });
  return content;
}

export function activate(context: vscode.ExtensionContext): void {
  context.subscriptions.push(
    vscode.commands.registerCommand(
      SHOW_SYNTHETIC_GRAPH_COMMAND,
      async (): Promise<string> => showText(getSyntheticGraphRenderText()),
    ),
    vscode.commands.registerCommand(
      SHOW_SELECTOR_REJECTION_COMMAND,
      async (): Promise<string> => showText(getSelectorRejectionText()),
    ),
  );
}

export function deactivate(): void {
  // No resources remain outside context-managed command registration.
}
