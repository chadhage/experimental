import { invokeGraph } from "../shared-core/index.js";

export const SYNTHETIC_VSCODE_SELECTOR = Object.freeze({
  projectName: "synthetic-vscode-surface",
});

/**
 * Calls the shared local fixture contract without adding VS Code-specific
 * rendering semantics. This function performs no network or credential access.
 */
export function getSyntheticGraphRenderText(): string {
  const result = invokeGraph(SYNTHETIC_VSCODE_SELECTOR);
  if (!result.ok) {
    throw new Error(result.error.message);
  }

  return result.value.renderText;
}

/**
 * Exercises the shared selector validation with neither selector present and
 * returns its exact local error text for the native VS Code surface.
 */
export function getSelectorRejectionText(): string {
  const result = invokeGraph({});
  if (result.ok) {
    throw new Error("Expected the shared core to reject a missing selector.");
  }

  return result.error.message;
}
