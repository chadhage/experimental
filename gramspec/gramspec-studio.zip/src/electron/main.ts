import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import { app, BrowserWindow } from "electron";

import {
  ELECTRON_WEB_PREFERENCES,
  installContentGuards,
  type GuardableWebContents,
} from "./security.js";

const moduleDirectory = dirname(fileURLToPath(import.meta.url));

export function resolveWebAssetPath(): string {
  // dist/electron/main.js and dist/web/index.html preserve the src layout.
  return join(moduleDirectory, "..", "web", "index.html");
}

export function createGraphWindow(): BrowserWindow {
  const webAssetPath = resolveWebAssetPath();
  const expectedUrl = pathToFileURL(webAssetPath).href;
  const graphWindow = new BrowserWindow({
    width: 1000,
    height: 760,
    show: process.env.GS_ELECTRON_SMOKE !== "1",
    webPreferences: ELECTRON_WEB_PREFERENCES,
  });

  installContentGuards(
    graphWindow.webContents as unknown as GuardableWebContents,
    expectedUrl,
  );

  graphWindow.webContents.session.webRequest.onBeforeRequest(
    {
      urls: [
        "http://*/*",
        "https://*/*",
        "ws://*/*",
        "wss://*/*",
        "ftp://*/*",
      ],
    },
    (_details, callback) => callback({ cancel: true }),
  );

  if (process.env.GS_ELECTRON_SMOKE === "1") {
    graphWindow.webContents.once("did-finish-load", async () => {
      try {
        const observation = await graphWindow.webContents.executeJavaScript(`
          (async () => {
            await new Promise((resolve) => setTimeout(resolve, 100));
            const validButton = document.getElementById("invoke-graph");
            const rejectionButton = document.getElementById(
              "invoke-graph-without-selector"
            );
            validButton.click();
            rejectionButton.click();
            await new Promise((resolve) => setTimeout(resolve, 50));
            return {
              validButtonTag: validButton.tagName,
              rejectionButtonTag: rejectionButton.tagName,
              status: document.getElementById("graph-status").textContent,
              result: document.getElementById("graph-result").textContent,
              rejection:
                document.getElementById("graph-rejection").textContent
            };
          })()
        `);
        console.log(`GS_ELECTRON_SMOKE ${JSON.stringify(observation)}`);
        app.exit(
          observation.result.includes("GS-CORE-API/v1") &&
            observation.rejection ===
              "INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId."
            ? 0
            : 1,
        );
      } catch (error) {
        console.error("GS_ELECTRON_SMOKE_ERROR", error);
        app.exit(1);
      }
    });
  }

  void graphWindow.loadFile(webAssetPath);
  return graphWindow;
}

void app.whenReady().then(() => {
  createGraphWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createGraphWindow();
  });
});

app.on("window-all-closed", () => {
  app.quit();
});
