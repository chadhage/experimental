export const ELECTRON_WEB_PREFERENCES = Object.freeze({
  contextIsolation: true,
  nodeIntegration: false,
  sandbox: true,
});

interface PreventableEvent {
  preventDefault(): void;
}

export interface GuardableWebContents {
  setWindowOpenHandler(
    handler: () => { action: "deny" },
  ): void;
  on(
    event: "will-navigate" | "will-redirect",
    handler: (eventValue: PreventableEvent, candidateUrl: string) => void,
  ): void;
  on(
    event: "will-attach-webview",
    handler: (eventValue: PreventableEvent) => void,
  ): void;
}

export function isExpectedLocalAsset(
  candidateUrl: string,
  expectedUrl: string,
): boolean {
  try {
    const candidate = new URL(candidateUrl);
    const expected = new URL(expectedUrl);
    return candidate.protocol === "file:" && candidate.href === expected.href;
  } catch {
    return false;
  }
}

export function installContentGuards(
  webContents: GuardableWebContents,
  expectedUrl: string,
): void {
  webContents.setWindowOpenHandler(() => ({ action: "deny" }));

  const denyUnexpectedNavigation = (
    eventValue: PreventableEvent,
    candidateUrl: string,
  ): void => {
    if (!isExpectedLocalAsset(candidateUrl, expectedUrl)) {
      eventValue.preventDefault();
    }
  };

  webContents.on("will-navigate", denyUnexpectedNavigation);
  webContents.on("will-redirect", denyUnexpectedNavigation);
  webContents.on("will-attach-webview", (eventValue) => {
    eventValue.preventDefault();
  });
}
