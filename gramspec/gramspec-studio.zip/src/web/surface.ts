import type {
  GraphRequest,
  GraphResult,
} from "../shared-core/index.js";

export const WEB_SURFACE_IDS = Object.freeze({
  invokeButton: "invoke-graph",
  invokeWithoutSelectorButton: "invoke-graph-without-selector",
  status: "graph-status",
  result: "graph-result",
  rejection: "graph-rejection",
});

export type GraphInvoker = (request: GraphRequest) => GraphResult;

export function visibleGraphOutput(result: GraphResult): string {
  return result.ok
    ? result.value.renderText
    : `${result.error.code}: ${result.error.message}`;
}

function requiredElement(documentValue: Document, id: string): HTMLElement {
  const element = documentValue.getElementById(id);
  if (element === null) {
    throw new Error(`Required web surface element is missing: ${id}`);
  }
  return element;
}

export function mountGraphSurface(
  documentValue: Document,
  graphInvoker: GraphInvoker,
): void {
  const invokeButton = requiredElement(
    documentValue,
    WEB_SURFACE_IDS.invokeButton,
  );
  const invokeWithoutSelectorButton = requiredElement(
    documentValue,
    WEB_SURFACE_IDS.invokeWithoutSelectorButton,
  );
  const status = requiredElement(documentValue, WEB_SURFACE_IDS.status);
  const resultRegion = requiredElement(documentValue, WEB_SURFACE_IDS.result);
  const rejectionRegion = requiredElement(
    documentValue,
    WEB_SURFACE_IDS.rejection,
  );

  invokeButton.addEventListener("click", () => {
    status.textContent = "Invoking local synthetic fixture…";
    const graphResult = graphInvoker({ projectName: "synthetic-local-demo" });
    resultRegion.textContent = visibleGraphOutput(graphResult);
    status.textContent = graphResult.ok
      ? "Synthetic local result rendered. No live interoperability."
      : `Local invocation rejected: ${graphResult.error.code}.`;
  });

  invokeWithoutSelectorButton.addEventListener("click", () => {
    status.textContent = "Invoking local synthetic fixture without a selector…";
    const graphResult = graphInvoker({});
    rejectionRegion.textContent = visibleGraphOutput(graphResult);
    status.textContent = graphResult.ok
      ? "Unexpected selector-free result rendered."
      : `Local invocation rejected: ${graphResult.error.code}.`;
  });
}

export function clickSmokeInvocations(documentValue: Document): void {
  requiredElement(documentValue, WEB_SURFACE_IDS.invokeButton).click();
  requiredElement(
    documentValue,
    WEB_SURFACE_IDS.invokeWithoutSelectorButton,
  ).click();
}
