import { invokeGraph } from "../shared-core/index.js";
import {
  clickSmokeInvocations,
  mountGraphSurface,
} from "./surface.js";

function startBrowserSurface(): void {
  mountGraphSurface(document, invokeGraph);

  // A deterministic, local-only hook lets the installed-Edge smoke entrypoint
  // exercise the native button without adding automation or network packages.
  if (globalThis.location.hash === "#gs-edge-smoke") {
    clickSmokeInvocations(document);
  }
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startBrowserSurface, {
      once: true,
    });
  } else {
    startBrowserSurface();
  }
}
