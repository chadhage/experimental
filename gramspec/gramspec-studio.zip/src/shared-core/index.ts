export const GS_CORE_API_VERSION = "GS-CORE-API/v1" as const;

export interface GraphRequest {
  readonly projectName?: unknown;
  readonly projectId?: unknown;
}

export interface SyntheticGraphFixture {
  readonly graphJson: string;
  readonly canonicalJson: string;
  readonly contentHash: string;
  readonly etag: string;
}

export interface GraphValue extends SyntheticGraphFixture {
  readonly apiVersion: typeof GS_CORE_API_VERSION;
  readonly renderText: string;
}

export type GraphResult =
  | { readonly ok: true; readonly value: GraphValue }
  | {
      readonly ok: false;
      readonly error: {
        readonly code: "INVALID_SELECTOR" | "INVALID_FIXTURE";
        readonly message: string;
      };
    };

const GRAPH_JSON =
  "{\n  \"factTypes\": [{\n    \"name\": \"SyntheticEnrollment\",\n    \"roles\": [\"student\", \"course\"]\n  }]\n}";
const CANONICAL_JSON =
  "{\"factTypes\":[{\"name\":\"SyntheticEnrollment\",\"roles\":[\"student\",\"course\"]}]}";
const CONTENT_HASH =
  "d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b";
const ETAG =
  "\"synthetic-d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b\"";

export const syntheticGraphFixture: SyntheticGraphFixture = Object.freeze({
  graphJson: GRAPH_JSON,
  canonicalJson: CANONICAL_JSON,
  contentHash: CONTENT_HASH,
  etag: ETAG,
});

const invalidSelector: GraphResult = Object.freeze({
  ok: false,
  error: Object.freeze({
    code: "INVALID_SELECTOR",
    message: "Provide exactly one non-empty projectName or projectId.",
  }),
});

const invalidFixture: GraphResult = Object.freeze({
  ok: false,
  error: Object.freeze({
    code: "INVALID_FIXTURE",
    message: "Synthetic fixture failed its declared integrity contract.",
  }),
});

function hasValidSelector(request: GraphRequest): boolean {
  const hasName =
    typeof request.projectName === "string" &&
    request.projectName.trim().length > 0;
  const hasId =
    typeof request.projectId === "string" && request.projectId.trim().length > 0;
  return hasName !== hasId;
}

function fixtureIsValid(value: unknown): value is SyntheticGraphFixture {
  if (typeof value !== "object" || value === null) return false;
  const fixture = value as Partial<SyntheticGraphFixture>;
  if (
    fixture.graphJson !== GRAPH_JSON ||
    fixture.canonicalJson !== CANONICAL_JSON ||
    fixture.contentHash !== CONTENT_HASH ||
    fixture.etag !== ETAG
  ) {
    return false;
  }

  const observedHash = sha256(fixture.canonicalJson);
  return observedHash === fixture.contentHash;
}

// Synchronous SHA-256 keeps the shared contract identical in Node, VS Code,
// Electron's sandboxed renderer, and a browser without importing Node APIs.
// It verifies only the fixture-declared bytes; it is not canonicalization.
function sha256(value: string): string {
  const bytes = new TextEncoder().encode(value);
  const bitLength = bytes.length * 8;
  const paddedLength = Math.ceil((bytes.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 0x80;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength, false);

  const words = new Uint32Array(64);
  const hash = new Uint32Array([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
  ]);
  const constants = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b,
    0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01,
    0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7,
    0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152,
    0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc,
    0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819,
    0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08,
    0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f,
    0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  const rotateRight = (word: number, bits: number): number =>
    (word >>> bits) | (word << (32 - bits));

  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const before15 = words[index - 15] ?? 0;
      const before2 = words[index - 2] ?? 0;
      const small0 =
        rotateRight(before15, 7) ^ rotateRight(before15, 18) ^ (before15 >>> 3);
      const small1 =
        rotateRight(before2, 17) ^ rotateRight(before2, 19) ^ (before2 >>> 10);
      words[index] =
        ((words[index - 16] ?? 0) +
          small0 +
          (words[index - 7] ?? 0) +
          small1) >>>
        0;
    }

    let [a, b, c, d, e, f, g, h] = hash;
    for (let index = 0; index < 64; index += 1) {
      const big1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = (e & f) ^ (~e & g);
      const temporary1 =
        (h + big1 + choice + (constants[index] ?? 0) + (words[index] ?? 0)) >>>
        0;
      const big0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = (a & b) ^ (a & c) ^ (b & c);
      const temporary2 = (big0 + majority) >>> 0;
      h = g;
      g = f;
      f = e;
      e = (d + temporary1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temporary1 + temporary2) >>> 0;
    }
    hash[0] = ((hash[0] ?? 0) + a) >>> 0;
    hash[1] = ((hash[1] ?? 0) + b) >>> 0;
    hash[2] = ((hash[2] ?? 0) + c) >>> 0;
    hash[3] = ((hash[3] ?? 0) + d) >>> 0;
    hash[4] = ((hash[4] ?? 0) + e) >>> 0;
    hash[5] = ((hash[5] ?? 0) + f) >>> 0;
    hash[6] = ((hash[6] ?? 0) + g) >>> 0;
    hash[7] = ((hash[7] ?? 0) + h) >>> 0;
  }

  return [...hash].map((word) => word.toString(16).padStart(8, "0")).join("");
}

function render(fixture: SyntheticGraphFixture): string {
  return [
    GS_CORE_API_VERSION,
    "Synthetic local fixture (no live interoperability)",
    `graphJson=${fixture.graphJson}`,
    `canonicalJson=${fixture.canonicalJson}`,
    `contentHash=${fixture.contentHash}`,
    `ETag=${fixture.etag}`,
  ].join("\n");
}

export function invokeGraph(
  request: GraphRequest,
  fixture: unknown = syntheticGraphFixture,
): GraphResult {
  // Selector validation intentionally precedes fixture access.
  if (!hasValidSelector(request)) return invalidSelector;
  if (!fixtureIsValid(fixture)) return invalidFixture;

  return {
    ok: true,
    value: {
      apiVersion: GS_CORE_API_VERSION,
      graphJson: fixture.graphJson,
      canonicalJson: fixture.canonicalJson,
      contentHash: fixture.contentHash,
      etag: fixture.etag,
      renderText: render(fixture),
    },
  };
}
