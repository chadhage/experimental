import { copyFile, mkdir } from "node:fs/promises";

import { build } from "esbuild";

await mkdir("dist/web", { recursive: true });
await Promise.all([
  copyFile("src/web/index.html", "dist/web/index.html"),
  copyFile("src/web/styles.css", "dist/web/styles.css"),
  build({
    entryPoints: ["src/web/index.ts"],
    bundle: true,
    format: "iife",
    outfile: "dist/web/index.js",
    platform: "browser",
    target: "es2022",
    sourcemap: false,
  }),
]);
