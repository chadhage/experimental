import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

await mkdir(".artifacts", { recursive: true });
const stagingDirectory = resolve(".artifacts", "vscode-package");
await rm(stagingDirectory, { force: true, recursive: true });
await mkdir(stagingDirectory, { recursive: true });

const sourceManifest = JSON.parse(
  await readFile("src/vscode/package.json", "utf8"),
);
sourceManifest.main = "./extension.js";
sourceManifest.files = ["extension.js", "LICENSE"];
sourceManifest.license = "UNLICENSED";
await writeFile(
  resolve(stagingDirectory, "package.json"),
  `${JSON.stringify(sourceManifest, null, 2)}\n`,
);
await writeFile(
  resolve(stagingDirectory, "LICENSE"),
  "UNLICENSED. Internal local evaluation artifact; no release is authorized.\n",
);
const esbuild = spawnSync(
  process.execPath,
  [
    resolve("node_modules", "esbuild", "bin", "esbuild"),
    "src/vscode/extension.ts",
    "--bundle",
    "--platform=node",
    "--format=cjs",
    "--external:vscode",
    `--outfile=${resolve(stagingDirectory, "extension.js")}`,
  ],
  { encoding: "utf8", shell: false },
);
process.stdout.write(esbuild.stdout ?? "");
process.stderr.write(esbuild.stderr ?? "");
if (esbuild.status !== 0) process.exit(esbuild.status ?? 1);

const run = spawnSync(
  process.execPath,
  [
    resolve("node_modules", "@vscode", "vsce", "vsce"),
    "package",
    "--no-dependencies",
    "--allow-missing-repository",
    "--out",
    resolve(".artifacts", "gramspec-studio-synthetic-graph-0.0.0.vsix"),
  ],
  { cwd: stagingDirectory, encoding: "utf8", shell: false },
);
process.stdout.write(run.stdout ?? "");
process.stderr.write(run.stderr ?? "");
process.exit(run.status ?? 1);
