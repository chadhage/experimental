import assert from "node:assert/strict";
import { test } from "node:test";

import { invokeGraph } from "../../src/shared-core/index.ts";

test("every local caller receives the same deterministic render contract", () => {
  const originalFetch = globalThis.fetch;
  let networkAttempts = 0;
  globalThis.fetch = () => {
    networkAttempts += 1;
    throw new Error("network access is prohibited");
  };

  try {
    const renders = [
      invokeGraph({ projectName: "same-project" }),
      invokeGraph({ projectId: "same-project-id" }),
      invokeGraph({ projectName: "same-project" }),
    ];
    assert.ok(renders.every((result) => result.ok));
    assert.equal(new Set(renders.map((result) => result.value.renderText)).size, 1);
    assert.equal(networkAttempts, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("selector rejection occurs without fixture access or state mutation", () => {
  let fixtureReads = 0;
  const guardedFixture = new Proxy(
    {},
    {
      get() {
        fixtureReads += 1;
        throw new Error("fixture must not be read");
      },
    },
  );

  assert.deepEqual(invokeGraph({}, guardedFixture), {
    ok: false,
    error: {
      code: "INVALID_SELECTOR",
      message: "Provide exactly one non-empty projectName or projectId.",
    },
  });
  assert.equal(fixtureReads, 0);
});
