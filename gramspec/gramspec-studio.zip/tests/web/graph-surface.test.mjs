import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";

import { invokeGraph } from "../../src/shared-core/index.ts";
import {
  mountGraphSurface,
  visibleGraphOutput,
} from "../../src/web/surface.ts";

class FakeElement {
  constructor() {
    this.textContent = "";
    this.listeners = new Map();
  }

  addEventListener(name, listener) {
    this.listeners.set(name, listener);
  }

  click() {
    this.listeners.get("click")?.();
  }
}

function fakeSurfaceDocument() {
  const elements = new Map(
    [
      "invoke-graph",
      "invoke-graph-without-selector",
      "graph-status",
      "graph-result",
      "graph-rejection",
    ].map((id) => [id, new FakeElement()]),
  );
  return {
    elements,
    getElementById(id) {
      return elements.get(id) ?? null;
    },
  };
}

test("web rendering is byte-identical to the shared core render output", () => {
  const sharedResult = invokeGraph({ projectName: "synthetic-local-demo" });
  assert.equal(sharedResult.ok, true);
  assert.equal(visibleGraphOutput(sharedResult), sharedResult.value.renderText);
});

test("native button invocation renders locally without network access", () => {
  const originalFetch = globalThis.fetch;
  let networkAttempts = 0;
  globalThis.fetch = () => {
    networkAttempts += 1;
    throw new Error("network access is prohibited");
  };

  try {
    const documentValue = fakeSurfaceDocument();
    mountGraphSurface(documentValue, invokeGraph);
    documentValue.elements.get("invoke-graph").click();

    const sharedResult = invokeGraph({
      projectName: "synthetic-local-demo",
    });
    assert.equal(
      documentValue.elements.get("graph-result").textContent,
      sharedResult.value.renderText,
    );
    assert.match(
      documentValue.elements.get("graph-status").textContent,
      /Synthetic local result rendered/,
    );
    assert.equal(networkAttempts, 0);
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("second native button cumulatively renders the exact selector rejection", () => {
  const documentValue = fakeSurfaceDocument();
  mountGraphSurface(documentValue, invokeGraph);

  documentValue.elements.get("invoke-graph").click();
  const validOutput = documentValue.elements.get("graph-result").textContent;
  documentValue.elements.get("invoke-graph-without-selector").click();

  assert.match(validOutput, /GS-CORE-API\/v1/);
  assert.equal(
    documentValue.elements.get("graph-result").textContent,
    validOutput,
  );
  assert.equal(
    documentValue.elements.get("graph-rejection").textContent,
    "INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId.",
  );
  assert.equal(
    documentValue.elements.get("graph-status").textContent,
    "Local invocation rejected: INVALID_SELECTOR.",
  );
});

test("HTML exposes native keyboard semantics and visible live output", async () => {
  const html = await readFile(
    new URL("../../src/web/index.html", import.meta.url),
    "utf8",
  );

  assert.match(html, /<button id="invoke-graph" type="button">/);
  assert.match(
    html,
    /<button id="invoke-graph-without-selector" type="button">/,
  );
  assert.match(html, /id="graph-status" role="status" aria-live="polite"/);
  assert.match(
    html,
    /id="graph-result"[\s\S]*role="region"[\s\S]*tabindex="0"/,
  );
  assert.match(
    html,
    /id="graph-rejection"[\s\S]*role="region"[\s\S]*tabindex="0"/,
  );
  assert.match(html, /connect-src 'none'/);
  assert.doesNotMatch(html, /src="https?:|href="https?:/);
  assert.match(html, /No live GramSpec interoperability/);
  assert.match(html, /Architecture semantics are (?:implemented or )?claimed/);
});
