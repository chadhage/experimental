import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";

const candidates = [
  process.env.EDGE_PATH,
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
].filter(Boolean);
const edgePath = candidates.find(existsSync);
assert.ok(edgePath, "Set EDGE_PATH or install Microsoft Edge.");

const buildRoot = process.env.GS_BUILD_ROOT ?? "dist";
const pageUrl = `${pathToFileURL(resolve(buildRoot, "web/index.html")).href}#gs-edge-smoke`;
const run = spawnSync(
  edgePath,
  [
    "--headless=new",
    "--disable-gpu",
    "--no-first-run",
    "--dump-dom",
    "--virtual-time-budget=1500",
    pageUrl,
  ],
  { encoding: "utf8", timeout: 30_000 },
);

assert.equal(run.status, 0, run.stderr);
assert.match(run.stdout, /GS-CORE-API\/v1/);
assert.match(
  run.stdout,
  /INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId\./,
);
assert.match(run.stdout, /Local invocation rejected: INVALID_SELECTOR\./);
console.log("Installed Edge rendered valid and selector-rejection output.");
