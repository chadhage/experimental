import assert from "node:assert/strict";
import { performance } from "node:perf_hooks";
import { test } from "node:test";

import {
  GS_CORE_API_VERSION,
  invokeGraph,
  syntheticGraphFixture,
} from "../../src/shared-core/index.ts";

const expectedFixture = {
  graphJson:
    "{\n  \"factTypes\": [{\n    \"name\": \"SyntheticEnrollment\",\n    \"roles\": [\"student\", \"course\"]\n  }]\n}",
  canonicalJson:
    "{\"factTypes\":[{\"name\":\"SyntheticEnrollment\",\"roles\":[\"student\",\"course\"]}]}",
  contentHash:
    "d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b",
  etag:
    "\"synthetic-d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b\"",
};

test("valid synthetic Graph result preserves raw bytes, role order, and stable rendering", () => {
  assert.deepEqual(syntheticGraphFixture, expectedFixture);

  const result = invokeGraph({ projectName: "synthetic-project" });

  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.value.apiVersion, GS_CORE_API_VERSION);
  assert.equal(result.value.graphJson, expectedFixture.graphJson);
  assert.equal(result.value.canonicalJson, expectedFixture.canonicalJson);
  assert.equal(result.value.contentHash, expectedFixture.contentHash);
  assert.equal(result.value.etag, expectedFixture.etag);
  assert.ok(
    result.value.graphJson.indexOf("\"student\"") <
      result.value.graphJson.indexOf("\"course\""),
  );
  assert.equal(result.value.renderText, [
    "GS-CORE-API/v1",
    "Synthetic local fixture (no live interoperability)",
    `graphJson=${expectedFixture.graphJson}`,
    `canonicalJson=${expectedFixture.canonicalJson}`,
    `contentHash=${expectedFixture.contentHash}`,
    `ETag=${expectedFixture.etag}`,
  ].join("\n"));
});

test("request requires projectName XOR projectId without hosted semantics", () => {
  for (const request of [
    {},
    { projectName: "name", projectId: "id" },
    { projectName: "" },
    { projectId: 42 },
  ]) {
    const result = invokeGraph(request);
    assert.deepEqual(result, {
      ok: false,
      error: {
        code: "INVALID_SELECTOR",
        message: "Provide exactly one non-empty projectName or projectId.",
      },
    });
    assert.equal("status" in result.error, false);
  }
});

test("fixture-declared presence, exact values, and SHA-256 integrity are enforced", () => {
  const invalidFixtures = [
    { ...expectedFixture, canonicalJson: undefined },
    { ...expectedFixture, canonicalJson: "{}" },
    { ...expectedFixture, contentHash: undefined },
    { ...expectedFixture, contentHash: "0".repeat(64) },
    { ...expectedFixture, etag: undefined },
    { ...expectedFixture, etag: "\"other\"" },
    { ...expectedFixture, graphJson: `${expectedFixture.graphJson} ` },
  ];

  for (const fixture of invalidFixtures) {
    assert.deepEqual(invokeGraph({ projectId: "synthetic-id" }, fixture), {
      ok: false,
      error: {
        code: "INVALID_FIXTURE",
        message: "Synthetic fixture failed its declared integrity contract.",
      },
    });
  }
});

test("local fixture invocation remains bounded without I/O", () => {
  const startedAt = performance.now();
  for (let index = 0; index < 10_000; index += 1) {
    const result = invokeGraph({ projectId: `synthetic-${index}` });
    assert.equal(result.ok, true);
  }
  assert.ok(
    performance.now() - startedAt < 1_000,
    "10,000 local invocations exceeded the proportionate one-second budget",
  );
});
