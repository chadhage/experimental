import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

const electronPath =
  process.env.ELECTRON_PATH ??
  (process.platform === "win32"
    ? resolve("node_modules", "electron", "dist", "electron.exe")
    : resolve("node_modules", ".bin", "electron"));
assert.ok(existsSync(electronPath), "Install the pinned local Electron package.");
const buildRoot = process.env.GS_BUILD_ROOT ?? "dist";

const run = spawnSync(electronPath, [resolve(buildRoot, "electron/main.js")], {
  encoding: "utf8",
  env: { ...process.env, GS_ELECTRON_SMOKE: "1" },
  timeout: 30_000,
});

const combinedOutput = `${run.stdout}\n${run.stderr}`;
assert.equal(run.status, 0, combinedOutput);
assert.match(combinedOutput, /GS_ELECTRON_SMOKE /);
assert.match(combinedOutput, /GS-CORE-API\\\/v1|GS-CORE-API\/v1/);
assert.match(
  combinedOutput,
  /INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId\./,
);
assert.match(combinedOutput, /Local invocation rejected: INVALID_SELECTOR\./);
console.log("Actual Electron rendered valid and selector-rejection output.");
