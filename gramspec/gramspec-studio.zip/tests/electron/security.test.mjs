import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";

import {
  ELECTRON_WEB_PREFERENCES,
  installContentGuards,
  isExpectedLocalAsset,
} from "../../src/electron/security.ts";

test("Electron renderer uses the required hardened preferences", () => {
  assert.deepEqual(ELECTRON_WEB_PREFERENCES, {
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: true,
  });
});

test("navigation, redirects, new windows, and webviews are denied", () => {
  const handlers = new Map();
  let windowHandler;
  const webContents = {
    setWindowOpenHandler(handler) {
      windowHandler = handler;
    },
    on(name, handler) {
      handlers.set(name, handler);
    },
  };
  const expected = "file:///local/dist/web/index.html";
  installContentGuards(webContents, expected);

  assert.deepEqual(windowHandler(), { action: "deny" });
  assert.equal(isExpectedLocalAsset(expected, expected), true);
  assert.equal(isExpectedLocalAsset("https://example.test/", expected), false);

  for (const name of ["will-navigate", "will-redirect"]) {
    let prevented = false;
    handlers
      .get(name)({ preventDefault: () => (prevented = true) }, "https://example.test/");
    assert.equal(prevented, true, `${name} must prevent external content`);
  }

  let webviewPrevented = false;
  handlers
    .get("will-attach-webview")({
      preventDefault: () => (webviewPrevented = true),
    });
  assert.equal(webviewPrevented, true);
});

test("Electron host loads only the same built web asset and has no IPC", async () => {
  const source = await readFile(
    new URL("../../src/electron/main.ts", import.meta.url),
    "utf8",
  );

  assert.match(source, /join\(moduleDirectory, "\.\.", "web", "index\.html"\)/);
  assert.match(source, /graphWindow\.loadFile\(webAssetPath\)/);
  assert.match(source, /webRequest\.onBeforeRequest/);
  assert.doesNotMatch(source, /\bipcMain\b|\bipcRenderer\b|\bpreload\b/);
});
