import assert from "node:assert/strict";
import { test } from "node:test";

import { invokeGraph } from "../../dist/shared-core/index.js";
import {
  getSelectorRejectionText,
  getSyntheticGraphRenderText,
  SYNTHETIC_VSCODE_SELECTOR,
} from "../../dist/vscode/adapter.js";

test("VS Code adapter returns the exact shared synthetic renderText", () => {
  const expected = invokeGraph(SYNTHETIC_VSCODE_SELECTOR);
  assert.equal(expected.ok, true);
  if (!expected.ok) return;

  assert.equal(getSyntheticGraphRenderText(), expected.value.renderText);
  assert.match(
    expected.value.renderText,
    /^GS-CORE-API\/v1\nSynthetic local fixture \(no live interoperability\)\n/,
  );
});

test("VS Code adapter returns the exact shared missing-selector error", () => {
  const expected = invokeGraph({});
  assert.equal(expected.ok, false);
  if (expected.ok) return;

  assert.equal(getSelectorRejectionText(), expected.error.message);
  assert.equal(
    getSelectorRejectionText(),
    "Provide exactly one non-empty projectName or projectId.",
  );
});

test("VS Code adapter does not use fetch or environment credentials", () => {
  const originalFetch = globalThis.fetch;
  const originalEnv = process.env;
  let networkAttempts = 0;

  globalThis.fetch = () => {
    networkAttempts += 1;
    throw new Error("network access is prohibited");
  };
  process.env = new Proxy(originalEnv, {
    get() {
      throw new Error("credential/environment access is prohibited");
    },
  });

  try {
    assert.doesNotThrow(() => getSyntheticGraphRenderText());
    assert.doesNotThrow(() => getSelectorRejectionText());
    assert.equal(networkAttempts, 0);
  } finally {
    globalThis.fetch = originalFetch;
    process.env = originalEnv;
  }
});
