import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { runTests } from "@vscode/test-electron";

const thisDirectory = path.dirname(fileURLToPath(import.meta.url));
const workspaceRoot = path.resolve(thisDirectory, "../..");
const vscodeExecutablePath = process.env.VSCODE_EXECUTABLE_PATH;

if (!vscodeExecutablePath) {
  throw new Error(
    "VSCODE_EXECUTABLE_PATH must name an installed VS Code executable; the smoke entrypoint will not download one.",
  );
}

const userDataDirectory = await mkdtemp(
  path.join(tmpdir(), "gramspec-studio-vscode-"),
);

try {
  await runTests({
    vscodeExecutablePath,
    extensionDevelopmentPath: path.join(workspaceRoot, "src/vscode"),
    extensionTestsPath: path.join(thisDirectory, "smoke-suite.cjs"),
    launchArgs: [
      "--disable-extensions",
      "--skip-welcome",
      "--skip-release-notes",
      "--user-data-dir",
      userDataDirectory,
    ],
  });
} finally {
  await rm(userDataDirectory, { force: true, recursive: true });
}
