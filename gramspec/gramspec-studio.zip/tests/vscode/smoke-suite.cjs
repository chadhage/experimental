"use strict";

const assert = require("node:assert/strict");
const vscode = require("vscode");

const VALID_COMMAND = "gramspecStudio.showSyntheticGraph";
const REJECTION_COMMAND = "gramspecStudio.showSelectorRejection";
const EXPECTED_REJECTION =
  "Provide exactly one non-empty projectName or projectId.";

async function run() {
  const extension = vscode.extensions.getExtension(
    "gramspec-studio-local.gramspec-studio-vscode",
  );
  assert.ok(extension, "the development extension was not discovered");
  await extension.activate();

  const registeredCommands = await vscode.commands.getCommands(true);
  assert.ok(
    registeredCommands.includes(VALID_COMMAND),
    `${VALID_COMMAND} is not registered`,
  );
  assert.ok(
    registeredCommands.includes(REJECTION_COMMAND),
    `${REJECTION_COMMAND} is not registered`,
  );

  const returnedRenderText =
    await vscode.commands.executeCommand(VALID_COMMAND);
  assert.equal(typeof returnedRenderText, "string");
  assert.match(
    returnedRenderText,
    /^GS-CORE-API\/v1\nSynthetic local fixture \(no live interoperability\)\n/,
  );

  const validEditor = vscode.window.activeTextEditor;
  assert.ok(validEditor, "the valid command did not show a visible text editor");
  assert.equal(validEditor.document.getText(), returnedRenderText);
  assert.equal(validEditor.document.languageId, "plaintext");
  assert.equal(validEditor.document.isClosed, false);

  const returnedRejectionText =
    await vscode.commands.executeCommand(REJECTION_COMMAND);
  assert.equal(returnedRejectionText, EXPECTED_REJECTION);

  const rejectionEditor = vscode.window.activeTextEditor;
  assert.ok(
    rejectionEditor,
    "the rejection command did not show a visible text editor",
  );
  assert.notEqual(rejectionEditor.document.uri.toString(), validEditor.document.uri.toString());
  assert.equal(rejectionEditor.document.getText(), EXPECTED_REJECTION);
  assert.equal(rejectionEditor.document.languageId, "plaintext");
  assert.equal(rejectionEditor.document.isClosed, false);
  assert.equal(validEditor.document.getText(), returnedRenderText);
  assert.equal(validEditor.document.isClosed, false);
}

module.exports = { run };
