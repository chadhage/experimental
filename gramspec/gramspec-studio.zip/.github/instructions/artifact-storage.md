# GRAMSpec Studio artifact-storage guidance

Status: authoritative workspace guidance  
Established: 2026-10-09  
Owner: human Factory owner (invoker)

## Sources and applicability

- Workspace decision `WS-01`: the owner authorized
  `C:\Users\chhage\repos\adhd-gramspec\agentic-factory\gramspec-studio` as the
  independently owned product workspace.
- ADHD `artifact-storage-and-engagement-contracts` skill, read from the
  separate framework repository on 2026-10-09.
- Product references to be verified before executable scaffolding:
  GRAM Architecture, GRAM Specification v1.1 and API Reference supplied by the
  owner; official VS Code extension and Electron guidance.

This file governs product, delivery, and Factory records in this workspace.
More specific repository instructions may refine it but must not create a
competing source of truth.

## Authoritative destinations

- Product source: `src/<product-specific-root>/` until a verified product
  reference prescribes a more specific compatible layout.
- Automated tests: `tests/`, or colocated with source when the selected
  framework convention requires it.
- Factory records: `docs/factories/gramspec-studio/`.
- Canonical engagement contract:
  `docs/factories/gramspec-studio/engagement-contract.md`.
- Product backlog: `docs/factories/gramspec-studio/backlog.md`.
- Authoritative unfinished-work board:
  `docs/factories/gramspec-studio/kanban.md`.
- Completion, demo, feedback, cycle, and outcome evidence:
  `docs/factories/gramspec-studio/evidence/`.
- Architecture and product decisions: `docs/architecture/`.
- Product-facing documentation: `docs/product/`.

Executable source, packages, generated binaries, credentials, private data,
and runtime state must not be stored under `docs/`.

## Naming, provenance, and retention

- Use filesystem-safe lowercase kebab-case paths and stable IDs in operational
  records.
- Preserve dated source URLs, versions, observations, counterevidence, command
  output summaries, and supersession links.
- Do not overwrite historical evidence; amend or supersede it.
- Never persist credentials. Minimize personal data; identify the invoker by
  role unless a name is necessary.
- Keep launch and delivery records for the life of the product repository.
  Generated build output and local runtime state are excluded from retention.

## Coordination and deviations

- The ProductOwner owns backlog ordering, Kanban owns board state, and delivery
  agents own implementation evidence. Shared-file writes are serialized.
- Any layout deviation must record its reference, rationale, approver,
  migration impact, and validation evidence in the product-reference ledger.
- No product artifact may be placed in the separate ADHD framework repository.
