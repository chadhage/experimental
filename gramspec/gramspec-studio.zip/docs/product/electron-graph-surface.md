# Electron synthetic Graph surface

## Host boundary

Electron is a thin desktop host for exactly the same local built web assets at
`dist/web/index.html`; it does not define another Graph renderer. The host uses
`contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true`.
Unexpected navigation, redirects, new windows, and attached webviews are
denied. HTTP, HTTPS, WebSocket, and FTP requests are cancelled. There is no
preload script and no IPC because this bounded surface needs neither.

All product and evidence qualifications from the web surface apply here: this
is a synthetic fixture demonstration with **no live GramSpec
interoperability**. GRAM Architecture semantics are explicitly excluded and
unvalidated. There is no network use, credential/private-data access,
persistence, exported telemetry, deployment, or release, and no claim for
download, version, hosted auth/rate-limit/error, canonicalization, or hosted
hash/ETag semantics.

The shared page exposes the same two native keyboard-operable controls in
Electron: one retains the valid `GS-CORE-API/v1` output and the other invokes
the shared core with neither selector, retaining the exact local
`INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId.`
output beside it.

## Build and checks

The integration build must retain the source layout in `dist/`, copy the web
HTML/CSS, bundle the browser script with the shared `invokeGraph` contract, and
compile `src/electron/main.ts` to `dist/electron/main.js`. The shared core is
browser-compatible and the same implementation is bundled into the web assets;
this host does not substitute divergent logic.

After the integrator's dependency install and build:

```powershell
npm run test:electron
node tests/electron/actual-electron.smoke.mjs
```

The second command launches the pinned local **actual Electron executable**,
loads the same `dist/web/index.html`, operates both native buttons, verifies
the valid shared render marker and exact selector rejection, and exits. It is
a local smoke check, not packaging, deployment, release, or live-service
interoperability.
