# VS Code synthetic Graph surface

## Supported boundary

The command **GRAMSpec Studio: Show Synthetic Graph (No Live
Interoperability)** (`gramspecStudio.showSyntheticGraph`) invokes the shared
`GS-CORE-API/v1` `invokeGraph` function with the synthetic selector
`{ projectName: "synthetic-vscode-surface" }`. It opens a native, visible,
plain-text VS Code document whose complete content is the shared result's exact
`renderText`; the adapter does not parse, reorder, or independently render it.
The second contributed command **GRAMSpec Studio: Show Selector Rejection
(Local)** (`gramspecStudio.showSelectorRejection`) invokes that same shared
function with neither selector (`{}`). It opens a native, visible, plain-text
document containing the exact shared local error:
`Provide exactly one non-empty projectName or projectId.` Both commands are
keyboard-operable through the VS Code Command Palette.

This is a deterministic local fixture demonstration corresponding only to the
observed default-inline shape of `GET /gramapi/Graph`. It performs no network,
credential, private-data, persistence, paid-service, telemetry-export,
deployment, or production-resource access. It does **not** claim live GRAMSpec
interoperability.

## Source mapping and limits

- API source: GRAM API Reference,
  <https://www.gramspec.com/GRAM/ApiReference>, partially observed on
  2026-10-10 for `GET /gramapi/Graph` and the default-inline `graphJson`,
  `canonicalJson`, `contentHash`, and `ETag` handling used by the shared core.
- Role-order source: GRAM Specification v1.1 §2.3,
  <https://www.gramspec.com/GRAM>, partially observed on 2026-10-10; serialized
  `roles` order is normative and is preserved by the shared core.

The source captures were partial. GRAM Architecture semantics are unvalidated
and excluded. Also excluded are authentication, authorization, rate limits,
hosted errors, a general canonicalization algorithm, server hashing or ETag
semantics, `download`, `versionId`, version/download behavior, other APIs,
runtime-agent autonomy, deployment, publication, and release.

## Local verification

No dependency installation or lockfile change is part of this surface.
With the repository's exact dependencies already installed, run from the
workspace root:

```powershell
npm run build
npm run test:vscode
```

For an actual Extension Development Host smoke check, supply the installed VS
Code executable externally. The entrypoint fails rather than downloading VS
Code when this variable is absent.

```powershell
$env:VSCODE_EXECUTABLE_PATH = 'C:\path\to\Code.exe'
node tests/vscode/run-smoke.mjs
```

The focused tests compare both the valid output and missing-selector rejection
with the shared core. The smoke check invokes both contributed commands,
verifies each opens a visible native text editor, and compares each complete
document with the exact string returned by its command. This is local
verification, not deployment or release.
