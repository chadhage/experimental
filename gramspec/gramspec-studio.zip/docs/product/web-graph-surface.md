# Web synthetic Graph surface

## Supported boundary

This surface is a local, deterministic demonstration of the source-observed
default-inline `GET /gramapi/Graph` shape selected by `GS-001`. Its native
valid button calls the shared `invokeGraph` contract with exactly one selector
and places that contract's `renderText` unchanged in a visible, focusable
result region. A second native button calls the same contract with neither
selector and renders its exact local
`INVALID_SELECTOR: Provide exactly one non-empty projectName or projectId.`
output in a separate visible, focusable rejection region. The regions are
separate so the valid and rejection outputs remain cumulatively visible. Both
buttons have native keyboard semantics, and the shared status region is
visible and announced politely.

The fixture is synthetic. There is **no live GramSpec interoperability**,
network request, credential lookup, private-data access, persistence, exported
telemetry, deployment, or release. GRAM Architecture semantics are explicitly
excluded and unvalidated. Download, `versionId`, hosted authentication,
authorization, rate limiting, canonicalization, hosted errors, and server
hash/ETag semantics are not implemented or claimed.

The partial source observations and limits are recorded by `GS-VOC-EVID-004`.
The selected behavior uses the observed API Reference Graph fields and the
GRAM Specification v1.1 §2.3 role-order rule; it does not claim the source
captures are complete.

## Build and checks

The integration owner must produce `dist/web/index.html`, `index.js`, and
`styles.css` from `src/web/`. `index.js` must be an IIFE/classic-script bundle
from `src/web/index.ts` and the shared core so the same assets work from a
local `file:` URL; it must not replace `invokeGraph`.
The shared core uses a synchronous browser-compatible SHA-256 implementation
only to check the fixture-declared `canonicalJson` bytes; it imports no Node
runtime API. The esbuild step therefore bundles that exact `invokeGraph`
implementation for the browser rather than duplicating or replacing it. This
bounded integrity check is not GRAM canonicalization or a hosted hash claim.

After the integrator's dependency install and build:

```powershell
npm run test:web
node tests/web/installed-edge.smoke.mjs
```

The Edge smoke entrypoint loads only `dist/web/index.html` from `file:` and
uses the page's local smoke hash to operate both native buttons. It should
observe `GS-CORE-API/v1`, the exact local `INVALID_SELECTOR` output, and the
rejection status while both outputs remain in the page. These commands are
local verification, not deployment or release.
