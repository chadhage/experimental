# GRAMSpec Studio authoritative product backlog

- **Backlog owner:** ProductOwner
- **Engagement contract:** `GS-ENG-001`
- **Status:** active for ordering and first-cycle selection
- **Established:** 2026-10-09
- **Authority horizon:** one bounded first value cycle only
- **Storage guidance:** `.github/instructions/artifact-storage.md`
- **Decision authority:** the ProductOwner may order the backlog and select the
  first-cycle outcome within `GS-ENG-001`; the human Factory owner retains
  strategy, investment, future-cycle, deployment, and release decisions.
- **Affected groups:** GRAM users, VS Code users, desktop and web-UI users,
  operators, maintainers, and people whose content future runtime agents may
  process. No contact, recruitment, private-data use, or subject research is
  authorized.

## ProductOwner acceptance and decision

**ACCEPT.** The ProductOwner accepts the assignment recorded in `GS-ENG-001`:
own and order this backlog, select the smallest integrated first-cycle outcome,
define its product acceptance and Done inputs, and maintain later-iteration
hypotheses without treating them as authority. This acceptance does not approve
spending, implementation outside the first cycle, external contact, private
access, deployment, or release.

**Selected first-cycle card:** `GS-001`.

**Outcome decision (recovery-panel round 2, final selection):** use the
source-observed contract of `GET /gramapi/Graph` behind one shared local
contract and make its result visible through keyboard-operable VS Code,
Electron, and web UI interactions. The first-cycle boundary is an explicitly
synthetic local fixture: it makes no live hosted-service interoperability
claim and uses no network, credentials, private data, persistence, or external
service. This final selection supersedes the provisional
`GET /gramapi/Projects` choice recorded in `GS-VOC-EVID-004`.

**Decision history:** the backlog originally deferred operation selection
pending source observation. `GS-VOC-EVID-004` then assessed
`GET /gramapi/Projects` as a provisional low-shape-complexity hosted candidate.
Recovery-panel round 2 selects `GET /gramapi/Graph` instead because its
source-observed graph payload permits a bounded local fixture to exercise the
GRAM v1.1 §2.3 normative role-order rule. The unobserved GRAM Architecture
semantics are explicitly excluded and unvalidated.

This is the smallest outcome that directly crosses the product boundary defined
by the mandate. A reference inventory or disconnected shells would reduce
delivery risk but would not satisfy the predeclared first-cycle value outcome.

## Evidence register

| Evidence ID | Evidence | Product use and limits |
| --- | --- | --- |
| `E-GS-ENG-001` | `docs/factories/gramspec-studio/engagement-contract.md`, updated 2026-10-09 | Authorizes setup and one bounded first cycle; defines affected groups, exclusions, value criteria, and inherited DoD. It is mandate evidence, not customer validation. |
| `E-STORAGE-001` | `.github/instructions/artifact-storage.md`, established 2026-10-09 | Establishes this file as the authoritative backlog destination and requires dated source provenance. |
| `E-GRAM-ARCH-URL` | Owner-authorized public GRAM Architecture source: `https://www.gramspec.com/Architecture`, recorded in `GS-ENG-001` and `GS-VOC-EVID-001` | Exact source location is available, but no page content, version marker, or section passage has been observed. Architecture semantics are excluded from and unvalidated by `GS-001`. |
| `E-GRAM-SPEC-URL` | Owner-authorized public GRAM Specification v1.1 source: `https://www.gramspec.com/GRAM`, recorded in `GS-ENG-001` and observed in `GS-VOC-EVID-004` | The observed partial body identifies GRAM Specification v1.1 and §2.3 makes serialized `roles` array order normative: consumers must not reorder roles. Snapshot completeness remains unvalidated. |
| `E-GRAM-API-URL` | Owner-authorized public GRAM API Reference: `https://www.gramspec.com/GRAM/ApiReference`, recorded in `GS-ENG-001` and observed in `GS-VOC-EVID-004` | The observed partial body supports the bounded `GET /gramapi/Graph` request/result fields used below. It does not establish local fixture mode, live interoperability, exhaustive errors, or Architecture semantics. |
| `E-VOC-GS-001` | `docs/factories/gramspec-studio/evidence/2026-10-09-voc-first-cycle-evidence.md` (`GS-VOC-EVID-001`) | Available VOC evidence establishes a documentation-only operational baseline, source-gated selection rule, measures, and counterevidence. It does not establish customer demand, adoption, willingness to pay, or profitable demand. |
| `E-VOC-GS-004` | `docs/factories/gramspec-studio/evidence/2026-10-10-voc-gs-001-public-source-validation.md` (`GS-VOC-EVID-004`) | Observes partial GRAM v1.1 and API Reference bodies, inventories eight REST sections, preserves the reported seven-versus-eight mismatch, and assesses the provisional `Projects` candidate. It is technical-source evidence, not live-service, Architecture, customer-demand, or financial validation. |

## Ordering policy

1. Satisfy mandatory safety, authority, source-traceability, and integrated-value
   gates before feature breadth.
2. Prefer the smallest deterministic vertical outcome that is observable in all
   required surfaces and shares one behavioral contract.
3. Next reduce conformance and failure-mode risk, then broaden verified API
   coverage by cohesive capability groups.
4. Defer agentic behavior until its runtime roles, permissions, data boundaries,
   and human controls are explicitly decided.
5. Do not financially approve an item without a human-approved portfolio policy
   and traceable delivery/lifecycle estimates.

## Ordered backlog

### 1. `GS-001` — One source-traceable GRAM invocation across all required surfaces

- **Disposition / cycle:** accepted and selected for authorized iteration 1;
  recovery-panel round-2 operation selection is final; **not True Ready**
  until the remaining delivery-input gaps below are closed
- **Parent / owner:** GRAMSpec Studio / ProductOwner
- **Customer segment and job:** provisional affected groups are GRAM users
  working from VS Code, desktop, or web UI; they need one consistent way to
  invoke and inspect a GRAM behavior. This is a testable product hypothesis,
  not validated VOC.
- **Desired outcome:** one shared, deterministic local-fixture implementation
  of the source-observed `GET /gramapi/Graph` contract produces identical
  visible output in VS Code, Electron, and web UI while preserving normative
  GRAM role order.
- **Evidence / counterevidence:** `E-GS-ENG-001`, `E-VOC-GS-001`, and
  `E-VOC-GS-004`; the observed API Reference identifies
  `GET /gramapi/Graph`, its mutually exclusive project selector, default
  inline response fields, and graph integrity fields. GRAM v1.1 §2.3 states
  that role order is normative and consumers must not reorder roles.
  Counterevidence retained as non-blocking for this bounded selection: the
  owner record reports seven REST endpoints while the observed API body has
  eight endpoint sections. This unresolved count does not alter the observed
  `Graph` section or its selected field behavior. The partial captures do not
  prove completeness, Architecture compatibility, customer demand, usability,
  technical feasibility, live interoperability, or profitable demand.
- **Scope:** implement one shared local contract corresponding only to
  `GET /gramapi/Graph` using an explicitly synthetic, repository-safe fixture;
  accept exactly one of `projectName` or `projectId`; exercise only the
  documented default inline response; preserve raw `graphJson` bytes and GRAM
  role order; carry and validate the presence/integrity relationships of
  `canonicalJson`, `contentHash`, and `ETag` without defining an unobserved
  canonicalization algorithm; expose one keyboard-operable interaction and
  identical visible output in VS Code, Electron, and web UI; document the
  source mapping and synthetic-only supported boundary.
- **Explicit exclusions:** additional API coverage, production concerns,
  external services, telemetry leaving the machine, private data, runtime-agent
  autonomy, deployment, publication, and release. Also excluded are live
  GramSpec interoperability, hosted authentication/authorization/rate-limit
  behavior, Architecture semantics, non-default `download` or `versionId`
  behavior, unspecified canonicalization, invented error taxonomies, download
  semantics, and version semantics.
- **Dependencies:** the dated partial-source observations in
  `E-VOC-GS-004`; Squad feasibility and local toolchain evidence; accepted
  Fullstacker assignments; authoritative Kanban transition controlled by
  Kanban; an explicitly synthetic fixture; and a local environment capable of
  the three surfaces. Architecture retrieval is not a dependency because
  Architecture semantics are outside this bounded slice.
- **Effort/capacity input:** unknown until Squad decomposition. Scope must fit
  one Squad of exactly three Fullstackers, WIP 1, and the authorized local
  runtime. ProductOwner does not manufacture an engineering estimate.
- **Priority rationale:** it is the only candidate that directly meets the
  first-cycle dissatisfier reduction while limiting breadth to one behavior.
- **Next test / review:** confirm Squad feasibility and run the predeclared BDD
  examples below against the synthetic fixture. Reopen operation selection
  only if contradictory source evidence invalidates the selected `Graph`
  fields or role-order rule, or if the bounded slice is infeasible.
- **Decision authority:** selected by ProductOwner under `GS-ENG-001`; Kanban
  alone controls board state; Squad controls implementation feasibility.

#### Product acceptance criteria

1. Dated citations identify the observed `GET /gramapi/Graph` default-inline
   request/result fields in the API Reference and the GRAM v1.1 §2.3
   normative role-order rule, with partial-capture limits stated.
2. A request supplies exactly one selector—`projectName` XOR `projectId`.
   Neither or both is rejected locally without inventing a hosted-service
   status code, error taxonomy, or recovery promise.
3. The default local success result contains the source-observed inline fields
   `graphJson`, `canonicalJson`, and `contentHash`, and exposes `ETag`
   presence/integrity handling. No acceptance claim is made for `download` or
   `versionId`.
4. The fixture's raw `graphJson` bytes are returned without rewriting, and
   arrays of GRAM roles retain their serialized order as required by GRAM
   v1.1 §2.3.
5. The implementation checks the presence and internally consistent handling
   of `canonicalJson`, `contentHash`, and `ETag` using fixture-declared
   expected values. It does not claim or invent an unspecified canonicalization
   algorithm or live server hashing/ETag semantics.
6. One shared behavioral contract drives all implemented surfaces. Given the
   same valid fixture, VS Code, Electron, and web UI each provide a
   keyboard-operable invocation and render byte-for-byte identical visible
   output; surface-specific logic does not redefine the result.
7. Invocation is local and deterministic and performs no network access,
   credential lookup, private-data access, paid-service call, persistence, or
   production-resource use. Product copy and evidence label it a synthetic
   fixture demonstration with no live interoperability claim.
8. Automated contract and integration tests cover selector XOR, default inline
   fields, raw `graphJson` byte identity, integrity-field presence/checks,
   role-order preservation, cross-surface output identity, and local
   no-network/no-credentials behavior. Typecheck and all required product
   builds pass from documented local commands.
9. A cumulative local demo is observed and recorded on VS Code, Electron, and
   web UI for the valid fixture and selector-XOR rejection; no deployment or
   release occurs.

#### BDD examples to refine against the verified API

- **Valid default-inline Graph fixture:** Given an explicitly synthetic local
  graph fixture and a request containing exactly one of `projectName` or
  `projectId`, when the user invokes it from VS Code, Electron, and web UI,
  then each surface shows identical visible output containing the default
  inline `graphJson`, `canonicalJson`, and `contentHash` values and the same
  `ETag`; raw `graphJson` bytes and serialized role order are unchanged; and
  no network or credential access occurs.
- **Selector XOR rejection:** Given neither selector or both selectors, when
  the user invokes the local fixture contract from any required surface, then
  the request is rejected consistently before fixture selection, no result is
  fabricated or state mutated, and no network or credential access occurs.
  This example asserts no hosted status code or other unobserved error
  semantics.
- **Integrity rejection:** Given a synthetic fixture whose declared
  `canonicalJson`, `contentHash`, or `ETag` expectation is absent or fails the
  implementation's fixture-defined integrity check, when invoked from any
  required surface, then all surfaces reject it consistently without
  rewriting `graphJson`, reordering roles, or claiming a source-defined
  canonicalization algorithm.

#### Definition-of-Done inputs and evidence required

- Traceable VOC need or an explicitly labeled unvalidated operational
  hypothesis and baseline; no fabricated customer claim.
- True Ready record with all gaps below closed before implementation.
- Refined observable BDD examples and failing-first TDD evidence where
  executable.
- Reproducible local build configuration; IaC is not applicable unless
  infrastructure is introduced.
- Privacy-conscious local-only instrumentation rationale, with no exported
  telemetry.
- Smallest integrated implementation using one shared contract.
- Contract/integration tests for selector XOR, default inline fields, raw-byte
  and role-order preservation, fixture-declared integrity handling,
  cross-surface identity, and no-network/no-credentials behavior; typecheck and
  builds; plus proportionate security and keyboard-accessibility assertions.
- Product documentation naming `GET /gramapi/Graph`, the observed sources and
  partial-capture limits, synthetic-only boundary, explicitly unvalidated
  Architecture semantics, excluded download/version/canonicalization/error
  semantics, local commands, and no-release status.
- Criterion-by-criterion evidence, backlog and Kanban reconciliation, observed
  cumulative local demo, residual risks, and a separate release decision.

#### True Ready gaps

1. `GS-VOC-EVID-004` closes the prior zero-source and unnamed-operation gaps
   with partial observed bodies, `GET /gramapi/Graph`, its bounded
   default-inline fields, and GRAM v1.1 §2.3. Capture completeness and the
   seven-versus-eight REST count remain unresolved counterevidence, but are
   non-blocking for this explicitly synthetic selection.
2. The repository-safe synthetic Graph fixture and its declared expected
   `canonicalJson`, `contentHash`, and `ETag` integrity values must be specified
   without inventing a general canonicalization or hosted error contract.
3. `GS-VOC-EVID-001` supplies an operational baseline, thresholds, and
   counterevidence; customer-demand and willingness-to-pay evidence remain
   absent, so the outcome remains an explicitly unvalidated operational
   hypothesis.
4. Three Fullstacker acceptances and atomic assignments are recorded in
   `GS-SQUAD-HANDOFF-001`; Squad feasibility, capacity estimate, and local
   toolchain confirmation remain absent for the selected synthetic `Graph`
   slice.
5. Required test/build/demo evidence locations and responsible atomic owners
   have not yet been assigned.

Architecture retrieval, live interoperability, and resolution of the
seven-versus-eight REST count are not readiness gates for this bounded slice.
Implementation must not begin while fixture integrity inputs, feasibility, or
required receiving-agent acceptance remains unresolved. Closing these
readiness gaps is authorized setup work; it is not a second investment gate
for iteration 1.

### 2. `GS-002` — Verified GRAM conformance inventory and coverage map

- **Disposition:** validate; ready-reserve candidate, not authorized for a
  future implementation cycle
- **Outcome:** map every source-confirmed invocable API to its normative source,
  dependencies, risk, surface relevance, and conformance-test status.
- **Evidence:** `E-GS-ENG-001`; requires `E-GRAM-ARCH-TBD`,
  `E-GRAM-SPEC-TBD`, and `E-GRAM-API-TBD`.
- **Acceptance hypothesis:** each inventory row has a stable ID, dated source
  citation, exact signature, behavioral rule, dependency/risk class, and
  coverage state; contradictions are explicit rather than resolved by guess.
- **Rationale:** creates traceable breadth and orders subsequent vertical
  slices without pretending the inventory itself is customer value.

### 3. `GS-003` — Shared conformance and error-behavior harness

- **Disposition:** investigate; reserve hypothesis only
- **Outcome:** make future source-confirmed APIs testable against one normalized
  request/result/error boundary across surfaces.
- **Dependencies:** delivered evidence from `GS-001`; verified inventory from
  `GS-002`; Squad architecture evidence.
- **Acceptance hypothesis:** adding a fixture detects behavioral divergence
  among core, VS Code, Electron, and web adapters without network or private
  data.

### 4. `GS-004` — Next cohesive low-dependency API capability

- **Disposition:** investigate; reserve hypothesis only
- **Outcome:** add the highest-value cohesive capability group supported by the
  verified inventory and VOC evidence, through the shared contract and all
  required surfaces.
- **Dependencies:** `GS-001`–`GS-003`; explicit future-cycle authorization.
- **Ordering note:** the operation names and group must not be invented before
  source verification.

### 5. `GS-005` — Safe local workspace and recovery flow

- **Disposition:** investigate; reserve hypothesis only
- **Outcome:** users can understand, retry, and recover supported local GRAM
  operations without data loss or hidden side effects.
- **Dependencies:** observed failure modes from delivered vertical slices and
  verified GRAM semantics.

### 6. `GS-006` — Accessible cross-surface workflow consistency

- **Disposition:** investigate; reserve hypothesis only
- **Outcome:** verified keyboard, focus, status, and error behavior remains
  consistent as supported API breadth grows.
- **Dependencies:** accessibility evidence from `GS-001` and subsequent
  source-confirmed flows.

### 7. `GS-007` — Runtime-agent boundary and human-control validation

- **Disposition:** defer
- **Outcome:** decide whether agentic product behavior should exist and, if so,
  define roles, tools, permissions, data handling, human confirmation,
  observability, safe interruption, and recovery before implementation.
- **Dependencies:** human architecture/data authority; VOC evidence; security
  and privacy review. No ADHD development agent is presumed to be a product
  runtime agent.

### 8. `GS-008` — Source-confirmed API coverage expansion

- **Disposition:** investigate; reserve hypothesis only
- **Outcome:** incrementally cover remaining invocable APIs in cohesive,
  independently demonstrable vertical slices.
- **Dependencies:** verified `GS-002` map, demonstrated prior slices, capacity,
  and explicit authorization for each future cycle.

### 9. `GS-009` — Local release-candidate quality assessment

- **Disposition:** defer
- **Outcome:** assess cumulative conformance, regression, accessibility,
  security, performance, recovery, documentation, and residual risks without
  releasing or deploying.
- **Dependencies:** meaningful source-confirmed coverage and explicit assessment
  authority. Candidate readiness is not release approval.

### 10. `GS-010` — Outcome review and next investment decision

- **Disposition:** defer
- **Outcome:** compare observed product and cost evidence with the original
  hypotheses and present a decision-ready continue/change/retire recommendation.
- **Dependencies:** verified increments, actual cost/capacity evidence, VOC
  evidence, and an approved portfolio investment policy if financial approval
  is requested.

## Provisional iteration outcome plan

Only iteration 1 is authorized. Iterations 2–10 are hypotheses for sequencing
and capacity discussion; they are neither selected work nor permission to
implement.

| Iteration | Outcome hypothesis | Candidate cards | Authority |
| --- | --- | --- | --- |
| 1 | One source-confirmed GRAM behavior works consistently through the shared local path and all three required visible surfaces. | `GS-001` | Authorized first cycle, subject to True Ready |
| 2 | A verified inventory makes API breadth, contradictions, and next slices traceable. | `GS-002` | Hypothesis; owner authorization required |
| 3 | A shared harness detects conformance and error divergence cheaply. | `GS-003` | Hypothesis; owner authorization required |
| 4 | The next evidence-backed low-dependency capability provides cumulative value across surfaces. | `GS-004` | Hypothesis; owner authorization required |
| 5 | Supported workflows fail and recover locally without hidden side effects or data loss. | `GS-005` | Hypothesis; owner authorization required |
| 6 | Cross-surface accessibility and interaction consistency withstand broader capability. | `GS-006` | Hypothesis; owner authorization required |
| 7 | Runtime-agent scope and human-control boundaries are validated or explicitly rejected before code. | `GS-007` | Hypothesis; consequential human decisions required |
| 8 | Remaining source-confirmed APIs expand in the next cohesive vertical slice, not disconnected layers. | `GS-008` | Hypothesis; owner authorization required |
| 9 | The cumulative local candidate has evidence-backed quality and residual-risk assessment. | `GS-009` | Hypothesis; no release authority |
| 10 | Forecast-versus-actual evidence supports a continue/change/retire investment decision. | `GS-010` | Hypothesis; human investment decision |

## Economics and investment status

- **Portfolio policy:** unknown and not configured. Missing inputs include the
  approved policy reference/version, currency, horizon, baseline, applicable
  ROI/NPV definitions and thresholds, discount-rate basis, payback limit, and
  strategic/mandatory exception rules.
- **Benefits:** unquantified. The first-cycle operational benefit hypothesis is
  reduced risk that Studio remains only a plan or divergent shells; customer
  demand and willingness to pay are not established.
- **Costs:** monetary spending is prohibited. Local time, compute, opportunity
  cost, lifecycle maintenance, and delivery capacity are unknown and must not be
  represented as zero.
- **Financial disposition:** no item is financially approved. Iteration 1 is
  authorized by the human as a bounded validation/value cycle, not by an
  invented investment hurdle or positive ROI claim.
- **Break-even/downside analysis:** unavailable until compatible benefit and
  lifecycle-cost estimates exist. The controlled downside is one local bounded
  cycle with no spending, deployment, release, external contact, or private
  access.

## Reopen, escalation, and recovery

Reopen the `GS-001` selection if governing source evidence shows no technically
feasible low-dependency invocable API, required surfaces cannot share the
behavior in the authorized runtime, acceptance evidence fails, or the human
amends/stops the mandate. Escalate safety, permission, resource, or
consequential architecture decisions; do not hide them behind priority.

The ProductOwner is available to the `GS-ENG-001` recovery panel for the current
authorized runtime and will provide one evidence-backed priority recommendation
within mandate. Product priority cannot waive source traceability, engineering
feasibility, quality gates, privacy/security obligations, or human-owned
investment and release decisions.
