# GRAMSpec Studio — authoritative unfinished-work board

- **Board owner:** Kanban
- **Engagement contract:** `GS-ENG-001`
- **Scope:** launch setup and the one human-authorized first value cycle only
- **Reporting timestamp:** `2026-10-10T02:19:09.895-04:00`
- **Workflow:** exactly `To Do` and `In Progress`
- **Delivery WIP limit:** 1 card. Setup, evidence, escalation, and
  orchestration cards do not consume delivery WIP.
- **Current delivery WIP:** 0 of 1; not exceeded; headroom 1
- **Iteration authority:** first bounded value cycle only. `GS-001` is
  verified Done Done in `GS-001-COMP-001`. No later cycle, deployment,
  publication, or release is authorized.
- **Completion handoff:** `GS-001`, `GS-ESC-001`, `GS-FC-002`, and
  `GS-FC-003` were removed only after their criterion-level verification was
  recorded in
  `evidence/2026-10-10-gs-001-completion.md`.
- **Release state:** withheld; no release or deployment occurred.

## Board policy

`To Do` and `In Progress` are the only live buckets. Blocked, waiting, review,
paused, stale, and at-risk are attributes. A delivery card may enter
`In Progress` only when True Ready, evidenced as started, owned, authorized,
and within delivery WIP 1. A card leaves this unfinished board only after its
exit criteria and verification evidence are recorded in the established
completion record.

## To Do

### `GS-FC-001` — Restore and verify the governing GRAM source packet

- **Owner:** VOC
- **Parent / dependency:** broader source support for the GRAMSpec Studio
  Factory; the bounded source disposition used by completed `GS-001` is
  recorded in `GS-001-COMP-001`.
- **Exit criteria:** exact locations, versions/dates, normative status, and
  relevant sections of GRAM Architecture, GRAM Specification v1.1, and the
  GRAM API Reference are durably inventoried; candidate invocable APIs,
  dependencies, contradictions, and exact citations are available to
  ProductOwner and Squad.
- **Status:** partial GRAM v1.1 and API Reference bodies were observed in
  `GS-VOC-EVID-004` and were sufficient only for the completed bounded
  synthetic `GET /gramapi/Graph` slice. No broader source work is active.
- **Blocker / risk:** **blocked and at risk.** Architecture content and capture
  completeness remain unvalidated, and the reported seven REST endpoints
  versus eight observed endpoint sections remains unresolved. The card's
  broader exit criteria are not complete.
- **Next action:** VOC or the human Factory owner supplies and verifies the
  missing complete source packet and reconciles the endpoint-count
  contradiction under existing source/data permissions. Do not reopen
  `GS-001` or infer broader source conformance.
- **Last updated:** 2026-10-10
- **Sources:** `GS-VOC-EVID-004`; backlog `GS-001`; `GS-ENG-001`;
  `GS-001-COMP-001`; historical VOC and core-integrator recovery evidence

## In Progress

None.

## Reconciled total lot

- **Total unfinished:** 1 (`GS-FC-001`)
- **To Do:** 1 (`GS-FC-001`)
- **In Progress:** 0
- **Blocked:** 1 (`GS-FC-001`)
- **At risk:** 1 (`GS-FC-001`)
- **Waiting:** 0
- **Stale:** 0 evidenced; no stale-age threshold is configured
- **Unowned:** 0
- **Dependency-constrained:** 1 (`GS-FC-001`)
- **Evidence-deficient for transition/removal:** 1 (`GS-FC-001`)
- **Delivery WIP:** 0 of 1; limit not exceeded; headroom 1
- **Ready reserve:** 0; no later delivery cycle is authorized

Attribute counts overlap and are not additional workflow buckets.

## Reconciliation and authorized changes

Source precedence is: the current explicit human instruction and accepted
`GS-ENG-001`; ProductOwner's backlog for product criteria; workspace storage
guidance; `GS-001-COMP-001`; corrected `GS-001-IMPL-001`; retained source,
tests, product docs, configuration, and lockfile; then dated readiness, VOC,
feasibility, restart, handoff, and recovery evidence.

Authorized changes applied:

1. recorded reacceptance by the replacement runtime in the existing single
   Kanban seat without adding a participant or authority;
2. independently reconciled all nine `GS-001` acceptance criteria and every
   applicable inherited Definition-of-Done criterion;
3. verified that the corrected 16/16 test total matches the retained test
   corpus and that the retained shared-core/browser-compatibility statements
   no longer contradict source or completion evidence;
4. created `GS-001-COMP-001`, removed `GS-001` as Done Done, and set delivery
   WIP to 0/1;
5. verified and removed `GS-ESC-001`, `GS-FC-002`, and `GS-FC-003` only for
   their own bounded administrative exit criteria; and
6. retained `GS-FC-001` exactly once because its broader source exit criteria
   remain incomplete.

All known authorized unfinished work appears exactly once. There are no
duplicates, omissions, orphan children, contradictory bucket states, or
unauthorized scope items. Backlog `GS-002`–`GS-010` remain unauthorized future
hypotheses and are not on the board. Release remains withheld.

**Next required human decision:** none for this board correction. Any next
value cycle, source-scope amendment, deployment, publication, or release
requires separate human authority.
