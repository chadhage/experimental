# GS-001 implementation evidence

- **Evidence ID:** `GS-001-IMPL-001`
- **Recorded:** 2026-10-10
- **Card / task:** `GS-001` / root/shared-core stage
- **Engagement:** `GS-ENG-001` (`Accepted`)
- **Authority / seat:** the current human Factory owner directed continuation
  in the existing accepted `studio-core-integrator` seat. No new engagement
  seat or assignment was created. The existing accepted `studio-core-cli`
  tooling-executor seat was addressed for bounded command execution.
- **Board state observed:** `GS-001` is `In Progress`, delivery WIP 1/1.
  This record does not edit or transition the Kanban board.

## Storage, ownership, and baseline

Storage follows `.github/instructions/artifact-storage.md` and the ADHD
`artifact-storage-and-engagement-contracts` skill read from
`adhd/.github/skills/artifact-storage-and-engagement-contracts/SKILL.md`.
There is no storage deviation.

Exclusive root/shared-core ownership for this stage is root configuration and
one lockfile, `src/shared-core/`, `tests/core/`, `tests/integration/`, and this
combined evidence record. Surface-owned source, tests, and product
documentation were not written. The canonical engagement contract and Kanban
were not changed.

The accepted readiness baseline is `GS-001-READY-001`: Node `v22.21.0`, npm
`10.9.4`, compatible exact package selections, the verbatim synthetic fixture,
and `GS-CORE-API/v1`. The workspace is not a Git worktree. This stage assumes
the readiness fixture and exact package selections remain authoritative.

## Mandatory failing-first test harness

Before any shared-core implementation or dependency installation, the
following focused tests and minimal root harness were created:

- `tests/core/graph-contract.test.mjs`
- `tests/integration/shared-render-contract.test.mjs`
- `package.json`

The tests specify selector XOR rejection, fixture-declared exact
value/presence and SHA-256 expectations, byte-identical raw `graphJson`,
normative role order, deterministic shared rendering, local source-neutral
errors, rejection before fixture access, and no attempted `fetch`.

The bounded executor was instructed to run, sequentially and without edits or
installation:

1. `npm run test:core`
2. `npm run test:integration`

The execution facility rejected the executor invocation before either npm
process started, with:

```text
Maximum sub-agent depth of 4 reached. Complete this task without spawning further sub-agents.
```

This is **not** an npm test result. Neither command has an exit code because
neither process was started. No failing-first test output is claimed.

Two bounded continuation attempts then tried to obtain direct local process
execution without changing the tests or starting implementation:

1. a direct-continuation runtime inspected the authorized files but reported
   that its interface exposed file view/edit operations and no direct
   CLI/process tool; and
2. a command-only runtime was asked to run exactly `npm run test:core` and
   `npm run test:integration` without edits, installation, or delegation, but
   likewise reported no direct CLI/shell tool.

For both attempts, both npm commands again have **no exit code because no
process started**. These observations do not replace the required failing-first
execution and do not establish any property of npm, Node, the tests, or the
host workstation.

## Stop decision

The card requires an actually executed failing-first test before implementation.
The available command-execution route was unavailable at the runtime depth
limit. This is an empirical quality-gate blocker and a contract stop condition.
Accordingly:

- dependencies were not installed;
- `package-lock.json` was not generated;
- `src/shared-core/` was not implemented;
- no exact package version or package-integrity result is claimed;
- no post-implementation test, typecheck, build, package, host smoke, or
  cumulative demo was run;
- no card completion, deployment, publication, or release is claimed.

## Intended interface packet (test-specified, not implemented)

The focused tests target `GS-CORE-API/v1` with a local `invokeGraph` entry
point accepting `projectName` XOR `projectId`. They require an explicit
`{ ok: true, value } | { ok: false, error }` result, stable render text,
verbatim fixture values, and source-neutral local errors. This is only the
test-specified receiving contract; there is no implementation artifact yet,
so surface owners must not integrate against it as completed code.

## Pending gates and restart point

Resume from the mandatory failing-first command execution in a runtime that
can start local processes without adding a roster seat. Preserve the current
tests and capture exact commands, exit codes, and meaningful failing output
before installing dependencies or creating `src/shared-core/`.

After that evidence exists, pending work remains: exact dependency install and
single lockfile, shared-core implementation, focused green tests,
typecheck/build, package-integrity review, surface integration, VS Code/web/
Electron tests and host smokes, accessibility/security checks, package gate,
cumulative demo, criterion-level reconciliation, Kanban-controlled completion,
and a separate release decision.

## 2026-10-10 tooling-executor recovery

The human Factory owner designated this runtime as a replacement for the
already-recorded accepted non-Fullstacker `studio-core-cli` tooling executor.
This was a command/write proxy recovery, not a new seat, assignment, or
decision-maker. `GS-001` remained `In Progress` at WIP 1/1, and neither the
Kanban board nor surface-owned paths were changed.

Before recovery began, a proxy had created
`src/shared-core/index.ts` and a short, manually fabricated
`package-lock.json` despite the absence of an actually observed failing-first
test. The separate `core-integrator-execution-evidence-004` record preserves
that historical breach and was not edited or concealed. Inspection also found
that implementation hashing used `graphJson`, contrary to the readiness
authority requiring SHA-256 over the exact `canonicalJson` bytes.

To restore the TDD gate honestly, this recovery removed both premature
artifacts from the workspace:

- `src/shared-core/index.ts`
- `package-lock.json`

No temporary implementation copy was needed. The pre-existing tests,
`package.json`, and `tsconfig.json` were preserved. A bounded command runner
was then invoked solely to start the required focused tests, sequentially,
without edits or installation.

| Sequence | Exact command | Exit | Exact key output |
|---|---|---:|---|
| 1 | `npm run test:core` | No exit code; process did not start | `I’m unable to execute the commands because this environment exposes no direct shell/command-execution tool, and you explicitly prohibited delegation.` |
| 2 | `npm run test:integration` | No exit code; process did not start | Not reached because the execution facility could not start either process. |

This is another execution-facility failure, **not** observed red test evidence.
Accordingly, recovery stopped at the mandatory quality gate. It did not run
`npm install`, did not generate a lockfile, did not recreate the
implementation, and did not claim focused green tests, typecheck, build,
package integrity, completion, deployment, release, or live behavior.

The workspace is intentionally left in the honest pre-implementation state:
the contract tests and exact-pinned `package.json` remain, while
`src/shared-core/index.ts` and `package-lock.json` are absent. The interface
packet remains test-specified only: `GS-CORE-API/v1`, selector XOR before any
fixture access, verbatim readiness fixture, fixture-declared exact checks,
SHA-256 over `canonicalJson` bytes, unchanged raw `graphJson` and roles order,
stable render text, and no network, credentials, environment access,
persistence, general canonicalization, or hosted semantics.

The sole blocker is a genuine runtime capability failure: no available
facility started the authorized npm processes. Recovery must resume with the
same two focused failing-first commands in a process-capable runtime. Only
after their real nonzero exits and key output are recorded may `npm install`
generate the complete lockfile and implementation proceed.

## Evidence-only integration follow-up — 2026-10-10T01:40:33.506-04:00

This append preserves the earlier record and reconciles the final observed
state only. It is performed by the continuation of the existing accepted
`studio-core-integrator` seat under `GS-ENG-001`; it is not a new seat,
scope, implementation attempt, board transition, completion request, or
release decision. The human invoker remains the current Factory owner.
Affected parties remain future GRAM, VS Code, desktop, web, operator, and
maintainer groups. No person was contacted and only repository-safe synthetic
data was involved, so additional consent or notice is not applicable.

### Actual 3/3 acceptance and collaboration record

The canonical contract's Studio-Core implementation-runtime amendment records
the following actual acceptances before any dependent work:

| Existing Fullstacker seat | Exact bounded acceptance retained in force | Actual collaboration observed in this stage |
| --- | --- | --- |
| `studio-core-integrator` | **ACCEPTED** exclusive root configuration and one lockfile, `src/shared-core/`, `tests/core/`, `tests/integration/`, serialized shared writes, integration, combined validation/evidence, the two surface handoff dependencies, and all recorded limits. | Specified the core boundary in tests, attempted to obtain the mandatory failing-first execution, removed the premature implementation and handwritten lockfile to restore the gate, and performed this evidence-only reconciliation. |
| `studio-vscode-surface` | **ACCEPTED** exclusive `src/vscode/`, `tests/vscode/`, and `docs/product/vscode-graph-surface.md` ownership; thin native adapter; dependency on the finalized core interface/root configuration; required failing-first, package, actual-host, and handoff evidence; and all recorded limits. | No implementation or receiving handoff occurred. The seat remained dependency-blocked. |
| `studio-electron-web-surfaces` | **ACCEPTED** exclusive `src/web/`, `src/electron/`, `tests/web/`, `tests/electron/`, and web/Electron product-documentation ownership; hardened thin-host boundary; actual-host and handoff evidence; and all recorded limits. | No implementation or receiving handoff occurred. The seat remained dependency-blocked. |

Each acceptance was by a replacement instance occupying its existing seat,
not by a new participant. Exactly three Fullstacker seats were retained. No
fourth Fullstacker was added, and no concurrency, pairing, review, integrated
handoff, host execution, or surface contribution is claimed. In particular,
the VS Code and web/Electron members did **not** begin dependent
implementation because the core interface remains test-specified only and no
implemented, failing-first-validated `GS-CORE-API/v1` packet exists.

### Atomic task graph, ownership, interfaces, and shared-write controls

1. **Acceptance gate — satisfied:** all three existing seats accepted the
   bounded assignments above; the Studio-Core coordinator acceptance is
   recorded in `GS-ENG-001`.
2. **Core red gate — blocked:** `studio-core-integrator` owns the two focused
   tests and must obtain real nonzero failing-first executions for
   `npm run test:core` and `npm run test:integration`.
3. **Core implementation gate — not started:** only after step 2 may the core
   owner run the exact dependency installation, allow npm to generate the
   complete single root lockfile, and implement `src/shared-core/`.
4. **Core verification and interface publication — not started:** focused
   green tests, typecheck, build, package-integrity review, and an implemented
   `GS-CORE-API/v1` packet must precede either surface handoff.
5. **Parallel surface adapters — dependency-blocked:** after step 4,
   `studio-vscode-surface` may write only its VS Code paths, while
   `studio-electron-web-surfaces` may write only its web/Electron paths.
   Neither may redefine GRAM semantics or edit root/shared files.
6. **Serialized integration — not started:** `studio-core-integrator` alone
   integrates collision-prone root configuration, manifests, the lockfile,
   shared schemas/fixtures, generated-artifact policy, and combined evidence;
   it then owns the combined tests, builds, host smokes, quality checks, and
   cumulative three-surface demo.

The test-specified interface is `GS-CORE-API/v1`: `invokeGraph` accepts a
non-empty `projectName` XOR `projectId` and returns an explicit discriminated
local result. The tests require selector rejection before fixture access,
verbatim readiness-fixture values, SHA-256 over exact `canonicalJson` bytes,
unchanged raw `graphJson` and serialized role order, stable shared render
text, source-neutral local errors, and no network attempt. This describes a
receiving contract only; there is no current implementation or callable
interface. Any change to interface, scope, or write ownership requires a
durable amendment and renewed acceptance by affected members.

### GS-001 product acceptance status

| Criterion | Status | Evidence and exact limitation |
| ---: | --- | --- |
| 1 | **Met (source-record level)** | Backlog `GS-001`, `GS-VOC-EVID-004`, and `GS-001-READY-001` retain dated partial-source provenance for API Reference `GET /gramapi/Graph` default-inline fields and GRAM v1.1 §2.3 role order. Partial-capture, unvalidated Architecture, and seven-versus-eight REST-count limits remain explicit. |
| 2 | **Blocked / not run** | Selector-XOR and source-neutral local rejection are specified in `tests/core/graph-contract.test.mjs` and `tests/integration/shared-render-contract.test.mjs`, but `src/shared-core/index.ts` is absent and no npm test process started. |
| 3 | **Blocked / not run** | The tests specify `graphJson`, `canonicalJson`, `contentHash`, and `etag`; no implementation or executed assertion proves the result. Download/version behavior remains excluded. |
| 4 | **Blocked / not run** | Exact raw bytes and `student`, then `course` role order are test-specified only. No implementation or executed result exists. |
| 5 | **Blocked / not run** | Fixture exact-value checks and SHA-256 over `canonicalJson` are test-specified. The removed premature implementation incorrectly hashed `graphJson`; no corrected implementation or run exists. |
| 6 | **Blocked / not run** | Shared stable render identity is specified in the integration test. No shared implementation, VS Code adapter, web UI, Electron host, keyboard interaction, or cross-surface run exists. |
| 7 | **Blocked / not run** | The local synthetic boundary is recorded and the integration test would count `fetch` attempts, but no executable implementation, host, documentation, or runtime assertion proves the complete no-network/no-credentials/no-private-data/no-persistence boundary. |
| 8 | **Blocked / not run** | Only core and integration test specifications exist. No test, install, typecheck, build, surface test, package check, security/accessibility/performance/recovery assertion, or complete product build ran. |
| 9 | **Blocked / not run** | No cumulative VS Code, Electron, or web demo was executed for valid or selector-rejection behavior. No deployment or release occurred. |

Thus criterion 1 has documentary source evidence; criteria 2–9 lack the
required empirical implementation evidence. `GS-001` is incomplete.

### Mandated gate ledger

| Gate | Final observed status and evidence |
| --- | --- |
| VOC | **Met for bounded technical hypothesis, not customer validation.** `GS-VOC-EVID-001` and `GS-VOC-EVID-004` establish the operational baseline, selected source-observed slice, measures, and counterevidence. Customer demand, usability, adoption, willingness to pay, and profitable demand remain unvalidated. |
| True Ready | **Previously met.** Kanban accepted `GS-001-READY-001` and moved `GS-001` to `In Progress` at WIP 1/1. Readiness did not pre-certify implementation or quality outcomes. |
| BDD | **Specified, not executed.** The valid default-inline, selector-XOR, and fixture-integrity examples are in backlog/readiness and represented by the focused tests. No executable result exists. |
| TDD | **Blocked at failing-first execution.** Tests preceded implementation, but every available Fullstacker/tooling-executor/task/general-purpose command route failed before npm process start. The premature implementation and handwritten lockfile were removed. There is no red exit or output and no permission to proceed to green. |
| IaC | **Accepted N/A.** No infrastructure or deployment environment is introduced by this local slice. Reproducible package/build configuration remains applicable but unverified. |
| Telemetry and instrumentation | **Rationale recorded; runtime check not run.** Intended evidence is local test/host output only, with no telemetry export. No host or implementation exists to verify it. |
| Implementation logic | **Not started in the final workspace.** The historically premature implementation recorded in evidence `004` was removed and is not counted as delivery. |
| Assertions | **Not run.** Core/integration tests exist as specifications. Focused tests, surface tests, typecheck, builds, package integrity, security, keyboard accessibility, performance, recovery, actual-host smokes, and cumulative demo have no process result. |
| Wiki/product documentation | **Not started / blocked.** No `docs/product/` directory or surface behavior documentation exists. This durable Factory evidence is not a substitute for product documentation. |
| Backlog hygiene | **Preserved.** This follow-up did not edit backlog or Kanban. It does not request Done because acceptance and Definition-of-Done evidence are incomplete. |
| Done Done | **Not achieved.** Criteria 2–9 and the inherited quality/documentation/demo requirements lack evidence; no completion record or board-removal request is warranted. |
| Potentially Shippable Increment | **No.** There is no integrated implementation, build, package candidate, or cumulative host demo. Deployment and release remain separately withheld and undecided. |

### Consolidated command and outcome ledger

No row below is an npm result. “No exit” means the requested operating-system
process never started.

| Route / sequence | Exact requested command | Observed outcome |
| --- | --- | --- |
| Initial bounded tooling executor | `npm run test:core` | **No exit; no process start.** Executor invocation was rejected at maximum sub-agent depth before npm started. |
| Initial bounded tooling executor | `npm run test:integration` | **No exit; no process start.** Not executed after the invocation-level rejection. |
| Direct Fullstacker continuation | `npm run test:core`; `npm run test:integration` | **No exits; no process starts.** Runtime exposed file view/edit operations but no direct CLI/process operation. |
| Command-only task/general-purpose continuation | `npm run test:core`; `npm run test:integration` | **No exits; no process starts.** Runtime reported no direct CLI/shell tool; delegation was not used as a substitute. |
| Tooling-executor recovery after artifact removal | `npm run test:core` | **No exit; no process start.** Reported: `I’m unable to execute the commands because this environment exposes no direct shell/command-execution tool, and you explicitly prohibited delegation.` |
| Tooling-executor recovery, second command | `npm run test:integration` | **No exit; no process start.** Not reached because the facility could not start either process. |
| Dependency install / lock generation | `npm install` | **Not run.** The failing-first gate was not established. |
| Post-implementation validation | focused tests, `npm run typecheck`, `npm run build`, all surface/integration tests, package and host commands | **Not run.** No implementation was authorized past the red gate. |

The earlier successful environment probes belong only to
`GS-001-READY-001`; they were not repeated here and do not prove these npm
commands ran.

### Artifact inventory and historical breach

**Durable artifacts retained in the final workspace for this slice:**

- `package.json` with the exact-pinned manifest and scripts;
- `tsconfig.json`;
- `tests/core/graph-contract.test.mjs`;
- `tests/integration/shared-render-contract.test.mjs`; and
- this implementation-evidence record, including all preceding history.

**Absent after gate restoration:**

- `src/shared-core/index.ts` — the premature implementation was removed;
- `package-lock.json` — the short handwritten lockfile was removed;
- all VS Code, web, and Electron source/tests/product documentation; and
- all implemented shared-core exports or runnable host artifacts.

**Generated/non-retained artifacts:** none were generated. In particular,
there is no `dist/`, `.artifacts/`, VSIX, Electron package, coverage output,
installed dependency result, or captured host/demo output.

Evidence `2026-10-10-gs-001-core-integrator-execution-evidence-004.md`
remains unchanged as the preserved historical record of the breach: a typed
implementation and manually fabricated short lockfile were written without
an observed failing-first run, the dependency installation and all validation
were unexecuted, and the implementation used the wrong hashing input. Their
later removal restores the gate; it does not erase, retroactively validate, or
relabel that event.

### Residual risks, blocker, and exact unblocking condition

The immediate blocker is runtime capability: every available execution route
in this continuation failed before starting the authorized npm processes.
Consequently, test executability, dependency integrity, implementation
correctness, package compatibility after installation, actual VS Code/web/
Electron integration, host security, keyboard accessibility, recovery,
performance, documentation, and demo behavior remain unknown. Source capture
completeness, Architecture semantics, live interoperability, customer demand,
and the seven-versus-eight REST mismatch remain the already-accepted
exclusions or counterevidence; no new claim resolves them.

Unblock only in a continuation of the same authorized seat where a direct
local process facility can run, without delegation substitution:

1. `npm run test:core`; and
2. `npm run test:integration`.

Both commands must actually start and their real nonzero exits and meaningful
failing output must be recorded against the unchanged pre-implementation
tests. Only then may `npm install` generate the complete lockfile and the
smallest core implementation proceed through focused green verification and
the dependent surface handoffs. Any different scope, ownership, permission,
or interface requires its own authorized amendment.

### Backlog hygiene and final workspace status

The authoritative backlog and Kanban were read only. `GS-001` remains
`In Progress`, WIP 1/1. This evidence-only append makes no Kanban edit, no
completion-record submission, and no Done request because the required
implementation, assertion, documentation, and demo evidence is incomplete.

`GS-001-READY-001` reported that the approved workspace is **not a Git
worktree**: its recorded `git rev-parse`, branch, HEAD, and status probes each
exited 128. No new Git command was executed in this runtime, so there is no
new branch, HEAD, status, diff, or mutation-accounting result to claim.

## Superseding process-capable continuation and completion submission

The historical blocker above was superseded in the same authorized card and
seat by the parent process-capable runtime explicitly supplied by the human
Factory owner. Historical failed process attempts and the recovered quality
breach remain preserved; they are not erased or relabeled.

### Failing-first and one-piece-flow evidence

Before implementation, the process-capable `studio-core-integrator` runtime
ran the unchanged focused tests:

| Command | Exit | Observed discriminating failure |
| --- | ---: | --- |
| `npm run test:core` | 1 | `ERR_MODULE_NOT_FOUND` for absent `src/shared-core/index.ts`; 0 passed, 1 failed |
| `npm run test:integration` | 1 | `ERR_MODULE_NOT_FOUND` for absent `src/shared-core/index.ts`; 0 passed, 1 failed |

Only after both observed-red results was the smallest shared implementation
created. The same tests then passed: core 3/3 and integration 2/2. The three
accepted Fullstacker seats subsequently delivered only their recorded atomic
paths. `studio-vscode-surface` explicitly reaccepted and owned `src/vscode/`,
`tests/vscode/`, and its product documentation.
`studio-electron-web-surfaces` explicitly reaccepted and owned `src/web/`,
`src/electron/`, their tests, and their product documentation. The integrator
serialized root/shared configuration, lockfile, combined fixes, validation,
packaging, and this evidence.

### Implementation and architecture

- One exact-pinned private npm workspace and lockfile implement the smallest
  coherent TypeScript scaffold; no service, database, cloud resource, or
  runtime-agent boundary was introduced.
- `GS-CORE-API/v1` accepts `projectName` XOR `projectId`, validates the exact
  synthetic fixture declaration and its SHA-256 over declared
  `canonicalJson`, returns raw `graphJson` bytes unchanged, and emits one
  stable render string. This bounded fixture check is not a general
  canonicalization or hosted ETag/hash claim.
- The fixture's role order remains `student`, then `course`. No parser,
  sorter, or reserialization touches `graphJson`.
- VS Code contributes native commands for the valid result and missing-selector
  rejection, each opening a visible plaintext document with shared text.
- The browser surface provides two native keyboard-operable buttons and
  separate focusable visible result regions for the valid and rejection
  outcomes. Electron loads exactly those local web assets.
- Electron uses `contextIsolation: true`, `nodeIntegration: false`, and
  `sandbox: true`; denies new windows, webviews, unexpected navigation and
  redirects; cancels HTTP/HTTPS/WebSocket/FTP requests; and introduces no
  preload or IPC.
- Content and documentation identify a synthetic local fixture, deny live
  GramSpec interoperability, and explicitly exclude unvalidated GRAM
  Architecture semantics.

### Final command ledger

Commands ran from the approved workspace unless a path is shown.

| Command | Exit / observed result |
| --- | --- |
| `npm install --ignore-scripts=false` | 0; 166 packages added, 169 audited, 0 vulnerabilities |
| `npm run typecheck` | 0 |
| `npm run build` | 0; TypeScript plus browser bundle/assets |
| `npm test` | 0; **16 passed, 0 failed**: core 4, VS Code 3, web 4, Electron 3, integration 2 |
| `npm run test:core` performance assertion | 0; 10,000 local calls completed in 103.6386 ms against a 1,000 ms proportionate budget |
| `npm run smoke:web` | 0; installed Microsoft Edge rendered both valid and selector-rejection output |
| `npm run smoke:electron` | 0; actual pinned Electron rendered both valid and selector-rejection output |
| `VSCODE_EXECUTABLE_PATH=<installed Code.exe>; npm run smoke:vscode` | 0; actual VS Code Extension Development Host executed and verified both native commands/documents |
| `npm run package:vscode` | 0; 5-file, 5.19 KB local VSIX candidate created |
| `npm audit --audit-level=high` | 0; 0 vulnerabilities |
| `npm ls --depth=0` | 0; exact direct graph includes TypeScript 7.0.2, Electron 41.10.7, esbuild 0.28.2, VSCE 4.0.0, VS Code test-electron 3.1.0, and recorded type packages |

The final VSIX candidate is generated, non-release evidence at
`.artifacts/gramspec-studio-synthetic-graph-0.0.0.vsix`, SHA-256
`798A3C422BCAE0759D5D48FF2FA42E39CFF4941F60E5B408DC5A3EBFCB27DB09`.
It was neither installed for end users nor published or released. `dist/`,
`.artifacts/`, `.vscode-test/`, and `node_modules/` are ignored
generated/local state. The retained `package-lock.json` SHA-256 is
`4747EB5CAC4A1836A760C6242656078CC335515BACC4829E14BCE9351B9F4F49`.

### Product acceptance matrix

| # | Acceptance criterion | Empirical result |
| ---: | --- | --- |
| 1 | Dated Graph/API and GRAM v1.1 §2.3 citations with partial limits | **Met.** Backlog, `GS-VOC-EVID-004`, readiness, and all three product docs preserve the dated partial-source limits, Graph mapping, normative role order, seven/eight counterevidence, and Architecture exclusion. |
| 2 | Exactly one selector; neither/both rejected locally without hosted semantics | **Met.** Core negative tests cover neither, both, empty, and wrong type; no status code exists. Visible missing-selector rejection passed in all three actual hosts. |
| 3 | Inline `graphJson`, `canonicalJson`, `contentHash`, and ETag | **Met.** Exact fixture and stable render tests pass; no `download` or `versionId` behavior exists. |
| 4 | Raw bytes and role order preserved | **Met.** Exact string equality and `student` before `course` assertions pass; all surfaces use shared render text. |
| 5 | Fixture-declared integrity only | **Met.** Missing/mismatched values and exact fixture SHA-256 are tested. Documentation denies general canonicalization and live server semantics. |
| 6 | One shared contract, identical visible output, keyboard operation | **Met.** Cross-surface identity tests pass; actual VS Code, Edge, and Electron hosts display shared output; native commands/buttons are keyboard operable. |
| 7 | Deterministic local execution with no prohibited access and clear copy | **Met.** Fetch/environment traps, CSP `connect-src 'none'`, Electron protocol cancellation, no credential library, no persistence/telemetry code, and product copy provide evidence. No live API call occurred. |
| 8 | Focused automation, typecheck, and builds | **Met.** 16 tests, typecheck, build, npm audit, package graph, and proportionate security/accessibility/performance/recovery assertions all pass. |
| 9 | Cumulative local three-host demo for valid and XOR rejection; no release | **Met.** All three actual-host smoke commands exited 0 and verified both cumulative outcomes. No deployment, publication, or release occurred. |

### Definition of Done and flow-gate matrix

| Gate | Result |
| --- | --- |
| VOC / hypothesis | Source-traceable, explicitly unvalidated operational hypothesis; no customer-demand or profitability claim is fabricated. |
| True Ready | Kanban recorded True Ready and moved the card to In Progress at WIP 1/1 before product implementation. |
| BDD / TDD | Backlog BDD valid, selector, and integrity examples are executable; observed red preceded implementation and focused green followed. The web rejection control also had an observed 2-pass/2-fail red before its implementation. |
| Reproducibility / IaC | Exact `package-lock.json`, scripts, and docs reproduce locally. IaC is not applicable because no infrastructure exists. |
| Instrumentation / privacy | Host/test console output only, no telemetry export, private data, credentials, or personal data. |
| Security / accessibility / performance / recovery | Hardened Electron and CSP/no-network tests pass; native keyboard controls, labeled live/focusable regions, and native VS Code documents are checked; 10,000-call budget passes; selector/integrity failures are deterministic and non-mutating. |
| Product documentation | Three surface documents record behavior, commands, synthetic-only limits, source mapping, Architecture exclusion, and no-release status. |
| Packaging / deployment | Local VSIX package candidate validated and hashed. Deployment, publication, and release are not authorized and did not occur. |
| Done Done submission | All nine acceptance criteria and applicable inherited DoD criteria have empirical evidence. Submitted to Kanban for completion-record reconciliation. |

### Residual risks and final status submitted

- Source captures remain partial; Architecture semantics and the
  seven-versus-eight REST mismatch remain unvalidated.
- No live GramSpec transport, authentication, authorization, rate limiting,
  download, version, hosted error, canonicalization, ETag, or hash
  interoperability is claimed or tested.
- Customer demand, usability with representative users, willingness to pay,
  production operations, and release readiness remain unvalidated.
- VSCE's informational 8.8 KB bundled-file size note is not a failure; the
  complete VSIX contains five files and is 5.19 KB.
- The workspace remains not a Git worktree. A final
  `git status --short --branch` therefore cannot report changed paths; initial
  Git probes exited 128. The retained file inventory and `.gitignore` define
  source versus generated state.

No human-only blocker remains for card completion. Release remains a separate,
withheld human decision. This evidence requests Kanban to reconcile `GS-001`
as Done Done and remove it from the authoritative unfinished-work board only
if Kanban independently accepts this matrix.
