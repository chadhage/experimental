# GS-001 VOC public-source validation

- **Artifact ID:** `GS-VOC-EVID-004`
- **Engagement / action:** `GS-ENG-001` / `GS-FC-001`
- **Work item:** `GS-001`, bounded first authorized cycle
- **Recorded:** `2026-10-10T01:01:33.446-04:00`
- **Human invoker:** current GramSpec Studio Factory owner, identified by role
- **VOC seat:** the single accepted VOC seat recorded in `GS-ENG-001`
- **Status:** **PARTIALLY VALIDATED — PRIOR ZERO-SOURCE BLOCKER
  SUPERSEDED; ARCHITECTURE AND SNAPSHOT-COMPLETENESS LIMITS REMAIN**
- **Supersedes as current VOC source finding:**
  `2026-10-10-voc-gs-001-source-recovery.md` (`GS-VOC-EVID-002`) and
  `2026-10-10-voc-gs-001-cli-http-recovery.md` (`GS-VOC-EVID-003`)
- **Storage:** `.github/instructions/artifact-storage.md`; approved destination
  `docs/factories/gramspec-studio/evidence/`; no deviation

## Authority, acceptance, subjects, and limits

**ACCEPT.** This runtime occupies the already accepted single VOC seat and
accepts only the owner-authorized `GS-FC-001` evidence action: validate the
three named public sources, inventory their invocable surfaces, and assess a
candidate first-cycle operation. This is not a new seat or a contract
amendment.

The human Factory owner authorized public retrieval and supplied local
retrieved bodies for GRAM v1.1 and the API Reference. No human subjects are
involved; consent and notice are **Not applicable** because the inputs are
public technical documentation and existing repository records. Affected
parties remain future users, operators, and maintainers; none were contacted.
No credentials, private data, spending, deployment, release, product-code
change, backlog change, Kanban change, or contract change occurred.

The artifact-storage skill at
`adhd/.github/skills/artifact-storage-and-engagement-contracts/SKILL.md`,
workspace storage guidance, canonical engagement record, prior VOC blockers,
and owner-supplied bodies were read before this write.

## Capture and provenance ledger

The two local files are untrusted owner-supplied retrieval outputs, not
independent live retrievals by this VOC runtime. The file-view operation
exposed their literal stored text. In both files, the final
`<note>Content truncated. Call the fetch tool ...</note>` is a retrieval/tool
display wrapper, not GramSpec source prose. It proves that the stored output
ends at a display boundary; it must not be interpreted as page content or as
confirmation that the preceding body is the complete page.

| Evidence ID | Canonical URL | Body/capture used and review time | Mapping and completeness | Integrity |
| --- | --- | --- | --- | --- |
| `GS-VOC-E17` | `https://www.gramspec.com/Architecture` | Public retrieval was authorized and attempted for this action at `2026-10-10T01:01:33.446-04:00`, but this invocation exposes no HTTP/process callable. No request or body was produced. | Canonical mapping is established by the owner and `GS-ENG-001`; content, final URL, status, headers, capture time, and completeness remain unobserved. | SHA-256 unavailable: no bytes and no hashing/process tool. |
| `GS-VOC-E18` | `https://www.gramspec.com/GRAM` | Owner-supplied local file `C:\Users\chhage\AppData\Local\Temp\1791608002106-copilot-tool-output-914fda8eb47844cbb2d15ccd21a07106.txt`; reviewed `2026-10-10T01:01:33.446-04:00`. Original retrieval time and HTTP metadata were not embedded. | File explicitly maps itself with `Contents of https://www.gramspec.com/GRAM:` and identifies **GRAM Specification (v1.1)**. It contains the Abstract and Sections 1 through part of 2.12, then a non-source truncation wrapper. It is a genuine partial body, not a complete snapshot. | SHA-256 unavailable because the callable tool surface has no hashing operation. |
| `GS-VOC-E19` | `https://www.gramspec.com/GRAM/ApiReference` | Owner-supplied local file `C:\Users\chhage\AppData\Local\Temp\1791608002095-copilot-tool-output-f10e976440514abd93d53c3861410a48.txt`; reviewed `2026-10-10T01:01:33.446-04:00`. Original retrieval time and HTTP metadata were not embedded. | File explicitly maps itself with `Contents of https://www.gramspec.com/GRAM/ApiReference:`. It contains Base URL, Authentication, MCP, rate limits, all eight named REST endpoint sections, supported databases, examples, and only the beginning of Error responses before a non-source truncation wrapper. It is operationally useful but incomplete. | SHA-256 unavailable because the callable tool surface has no hashing operation. |

This evidence supersedes the prior claim that zero source bodies are
observable: two mapped source bodies are now observable. It does **not**
retroactively turn the earlier zero-request attempts into HTTP retrievals, and
it does not establish a complete Architecture/GRAM/API snapshot packet.

## Source status and exact GS-001 passages

### Architecture — content not validated

- **Status:** intended architecture authority under `GS-ENG-001`, but its
  actual prose, version/date, normative force, and operational constraints
  remain unobserved.
- **GS-001 need:** component ownership, host/lifecycle, dependency, and
  cross-surface sharing constraints.
- **Exact passage:** none available. No architecture claim is inferred from
  the other two sources.

### GRAM v1.1 — normative specification, partial body

The observed title/Abstract calls the document the **“GRAM Specification
(v1.1)—a formal standard”**. Its content is normative for GRAM graph meaning,
not documentation of the hosted project-list operation.

Exact relevant passages observed:

> “Version 1.1 distinguishes the two layers at which a GRAM schema is
> consumed. For machine consumers, the operationally load-bearing content is
> the constraint modality—uniqueness, mandatoriness, and the cardinality
> classification they jointly determine—together with role-level
> identifiers.”

> “Role order is normative. The order of the `roles` array in the
> serialization binds each role to its position in the reading... Consumers
> must not reorder roles.”

These clauses would govern a fixture that contains a GRAM graph. They do not
define `GET /gramapi/Projects`, whose documented response contains project
metadata rather than a graph. The partial file stops in Section 2.12, so later
conformance, serialization, and deferral clauses mentioned by the Abstract
were not validated.

### API Reference — operational hosted-service reference, partial body

This is the operational authority for REST/MCP invocation. It is not evidence
that the service can be invoked locally without network or credentials.

Exact relevant passages observed:

> “Every request must carry an `X-Api-Key` header with a per-user API key.”

> “A key identifies a single GramSpec user and inherits that user's
> permissions; only **Enterprise** and **Admin** accounts can use the API.”

> “Missing or invalid keys get `401 Unauthorized`. A valid key on a
> non-Enterprise account gets `403 Forbidden`. Keep keys out of client-side
> code—treat them like a password.”

> “Requests are throttled per user. The prompt-and-export endpoints
> (`SystemPrompt`, `AnalystKit`, `Projects`, `Graph`, `BuildPrompt`, `Rules`)
> allow up to **120 requests per minute**... Over the limit you get `429 Too
> Many Requests` with body `{ "error": "rate_limited" }`.”

> “Lists the Grammar projects owned by the authenticated user. Use it to
> render a project picker, or to cache the stable `projectId`.”

The observed error table is cut off during its `400` row. No unobserved
remainder is reconstructed.

## Complete inventory of explicitly listed invocable surfaces

### REST APIs

| # | Method and path | Explicit purpose / notable inputs |
| --- | --- | --- |
| 1 | `GET /gramapi/SystemPrompt` | Assembled system prompt; one of `projectName`/`projectId`, required `databaseType`, optional `promptMode`. |
| 2 | `GET /gramapi/AnalystKit` | Prompt, graph, compact index, dossiers, and seven returned analyst-tool schemas; project selector and `databaseType`, optional `connectionName` and `syncedSqlSchema`. |
| 3 | `GET /gramapi/Projects` | Projects owned by authenticated user; no request parameter is listed. |
| 4 | `GET /gramapi/Graph` | Project graph; project selector, optional `download` and `versionId`. |
| 5 | `GET /gramapi/Versions` | Sealed project-version history; example uses `projectName`. |
| 6 | `POST /gramapi/BuildPrompt` | Structured prompt assembly; one of `graphJson`, `projectName`, or `projectId`, required `databaseType`, optional `promptMode`. |
| 7 | `GET /gramapi/Rules` | Rules template and dialect profile; example supplies `databaseType`. |
| 8 | `POST /gramapi/Query` | Managed model path; required `prompt` and `chatConfigId`, optional `provider` and `promptMode`. |

**Preserved contradiction:** the canonical owner record reports apparent
source prose describing **seven** REST endpoints, while the API Reference body
explicitly presents the **eight** endpoint sections above. This artifact does
not silently normalize the prose to eight. The partial body available here
does not expose the exact “seven REST endpoints” passage, so its precise
location and wording remain unverified; the eight-item section count is
directly observed.

The `AnalystKit` section separately lists seven client-side analyst tool
schemas—`run_query`, `search_graph`, `describe_entity`, `ask_user`,
`record_finding`, `record_ledger_entry`, and `end_turn`. Those are returned
tool contracts and must not be conflated with either the eight REST endpoints
or the eight MCP server tools.

### MCP APIs, resource, and prompt

The API Reference explicitly lists these eight MCP tools:

1. `list_projects`
2. `get_graph`
3. `graph_overview`
4. `describe_entity`
5. `search_graph`
6. `generate_sql`
7. `validate_sql`
8. `run_query`

It also lists:

- **Resource:** `gramspec://project/{projectId}/graph`
- **Prompt:** `analyst_system_prompt`, taking `projectName` and
  `databaseType`
- **MCP endpoint:** `https://gramspec.com/mcp`

The reference says all eight MCP tools declare themselves read-only. It also
qualifies that `run_query` performs read-only execution against a connected
graph's home database, `generate_sql` consumes AI allowance, and a graph
without a home connection can still serve non-executing tools. These are
hosted operational claims, not locally verified behavior.

## Candidate first-cycle operation: `GET /gramapi/Projects`

### Exact documented contract

- **Request:** `GET https://gramspec.com/gramapi/Projects`
- **Query/path/body parameters:** none are listed.
- **Authentication carrier:** required per-user `X-Api-Key`; the source says
  the same key is accepted through an Authorization carrier, but the supplied
  body redacts its exact value syntax, so no missing syntax is invented.
- **Response 200 example:** a JSON array of objects with:
  - `projectId`: stable project GUID;
  - `title`: project title; and
  - `modifiedUtc`: UTC modification timestamp.
- **Scope semantics:** projects “owned by the authenticated user.”

### Auth, network, and account constraints

A live call requires public network access to `https://gramspec.com`, a
credential tied to a GramSpec user, and an Enterprise or Admin account whose
plan remains active. The API key inherits that user's permissions and must not
be placed in client-side code. Those requirements directly conflict with the
explicit GS-001 local/no-network/no-credentials mandate.

### Error semantics actually supported by the observed source

- missing or invalid key: `401 Unauthorized`;
- valid key for a non-Enterprise account: `403 Forbidden`;
- per-user prompt/export rate limit, including `Projects`: 120 requests per
  minute;
- rate-limit response: `429 Too Many Requests` with
  `{ "error": "rate_limited" }`.

The partial Error responses table begins a general `400` description, but it
is truncated and `Projects` has no listed parameters. Therefore no
Projects-specific `400`, not-found, empty-account, malformed-response, retry,
ordering, pagination, caching, timeout, or service-unavailable semantic is
claimed. The source does not state that an empty project list is an error.

### Repository-safe synthetic-fixture decision

A repository-safe fixture can contain only invented project records matching
the three observed fields, for example synthetic GUID/title/timestamp values.
That can support deterministic rendering, keyboard/accessibility checks, and
shared-adapter tests without credentials, private data, or network access.

It **cannot**, on the available evidence, validate live GramSpec
interoperability or count as an actual invocation of the hosted operation:

1. the real result is account-owned mutable state;
2. authentication, permission, rate limiting, transport, and server behavior
   would be bypassed;
3. the reference defines no local emulator, fixture mode, public anonymous
   mode, or offline `Projects` contract; and
4. Architecture content has not been validated for a conforming shared
   adapter/lifecycle.

Accordingly, `GET /gramapi/Projects` is a low-shape-complexity **hosted API
candidate**, but it cannot satisfy an acceptance criterion requiring live
interoperability while the local/no-credentials/no-network mandate remains
explicit. A fixture-based product demo must be labeled a synthetic simulation,
not “GRAM API invoked,” and would require the human decision owner to decide
whether that narrower outcome satisfies GS-001. This artifact makes no such
product decision.

## Contradictions, counterevidence, and confidence

- The eight observed REST sections conflict with the reported “seven REST
  endpoints” prose. The count mismatch is unresolved.
- The API requires network, credentials, and qualifying account state;
  GS-001 explicitly prohibits all three for its local path. This disconfirms
  `Projects` as a live first-cycle operation under current acceptance terms.
- `Projects` returns metadata, not GRAM graph semantics. The observed GRAM
  v1.1 clauses do not add local processing behavior to it.
- Architecture compatibility is unknown because no Architecture body was
  observed.
- Both supplied bodies are partial retrieval outputs without HTTP status,
  final URL, headers, source update date, original capture time, or hash.
- No customer, telemetry, adoption, or payment evidence was collected. This
  is technical-source evidence only and does not validate demand.

**Confidence:** medium that the listed REST/MCP surface and the positive
`Projects` shape are accurately transcribed from the observed API body; low
for exhaustive error behavior and Architecture compatibility; high that a
synthetic fixture alone cannot demonstrate live authenticated interoperability.

## Remaining evidence blockers and next human decision

Genuine remaining evidence blockers are:

1. a captured Architecture body with retrieval time, canonical/final URL,
   completeness boundary, and relevant exact passages;
2. complete GRAM v1.1 and API Reference captures beyond both observed
   truncation wrappers, especially GRAM conformance/serialization sections and
   the full API Error responses section;
3. integrity hashes calculated by an authorized tool over the exact captured
   bytes; and
4. resolution of the seven-versus-eight REST prose mismatch.

The prior **zero-source-body** blocker is closed, but source completeness and
Architecture validation are not. The next human decision is whether GS-001 may
use an explicitly labeled local synthetic simulation as its first-cycle
outcome, or whether it must retain live-interoperability acceptance—in which
case `GET /gramapi/Projects` is incompatible with the current no-network and
no-credentials limits. No board or backlog transition is asserted here.
