# VOC first-cycle evidence inventory

## Recovery-runtime amendment — 2026-10-09T23:35:51.309-04:00

- **Runtime-role continuity:** **ACCEPT.** This VOC runtime instance accepts
  the same bounded `GS-ENG-001` VOC recovery assignment in place of the
  unavailable prior runtime instance. This is continuity of the one accepted
  VOC role, not a roster addition or scope change.
- **Human authority evidence:** owner instruction in the current invocation,
  dated `2026-10-09T23:35:51.309-04:00`.
- **Scope honored:** only the three owner-supplied public URLs below and
  existing product-workspace records were considered. No people were
  contacted; no private data/system was accessed; no spending, deployment,
  release, contract, backlog, or board change occurred.
- **Consent/notice:** **Not applicable** because no human subjects participated
  and no personal or private data was collected.
- **Storage:** amended in place under the authoritative
  `.github/instructions/artifact-storage.md`; this section supersedes the
  earlier claim below that the exact URLs were absent while preserving that
  earlier runtime's evidence and limitations.

### Exact public-source citations and retrieval status

The owner supplied these exact citations on 2026-10-09:

| Evidence ID | Exact source | Intended governing use | Retrieval observation at 2026-10-09T23:35:51.309-04:00 |
| --- | --- | --- | --- |
| GS-VOC-E08 | GRAM Architecture, https://www.gramspec.com/Architecture | Architecture boundaries, component/lifecycle constraints, and compatibility | The URL was available as owner-authorized input, but this runtime had no HTTP-capable retrieval interface. An attempted repository file read treated the URL as a local path and returned “does not exist”; no page content was obtained. |
| GS-VOC-E09 | GRAM Specification v1.1, https://www.gramspec.com/GRAM | Normative syntax, validity, processing, and result semantics | Same retrieval limitation; no page content was obtained. |
| GS-VOC-E10 | GRAM API Reference, https://www.gramspec.com/GRAM/ApiReference | Invocable API name/signature, parameters, return/error behavior, and prerequisites | Same retrieval limitation; no page content was obtained. |

These are exact, dated **source-location citations**, not claims about page
content. No section anchor, quotation, API signature, or semantic assertion is
recorded because none was observed. The failed local-path reads do not show
that the public pages are unavailable; they show only that this runtime's
provided read interface cannot perform HTTP retrieval. No alternative source
was substituted.

### Recovery finding: named API and governing semantics

**Exact recommended API: none—selection remains blocked.** It would be
fabrication to name an invocable API without observing `GS-VOC-E10`, or to
claim its governing semantics without reconciling `GS-VOC-E08` and
`GS-VOC-E09`. The prior source-gated selection rule remains the recommendation:
choose the first explicitly invocable API that is architecture-compatible,
normatively specified, deterministic with a bounded synthetic fixture, local
and credential-free, and exposes documented success plus invalid/unsupported
behavior through one shared contract.

The governing semantics that must be extracted before implementation are:

1. the API Reference's exact callable name, signature, parameter domains,
   return shape, prerequisites, and documented failure behavior
   (`GS-VOC-E10`);
2. the Specification v1.1 clauses defining valid and invalid input,
   normalization/processing, observable result, and any ordering or state
   rules (`GS-VOC-E09`); and
3. the Architecture constraints on ownership, lifecycle, dependencies, host
   boundaries, and whether sharing one implementation across the authorized
   surfaces is conformant (`GS-VOC-E08`).

All of those are required evidence fields, not inferred semantics.

### Synthetic fixture possibilities

The following are **test-design possibilities, not source-validated fixtures**
and must stay out of executable acceptance evidence until mapped to exact
clauses and the selected API signature:

- **Valid-minimal:** the smallest wholly synthetic input explicitly accepted
  by the selected API, with every required field present and no optional
  content; expected output copied from or derived strictly from normative
  rules.
- **Valid-boundary:** a synthetic input at one documented legal boundary
  (empty collection only if allowed, minimum length/value, or one supported
  construct) to expose hidden host/state assumptions.
- **Invalid-syntax/type:** one synthetic input violating a documented
  grammar/type requirement; expected error category and timing must come from
  the sources rather than being invented.
- **Unsupported-but-well-formed:** one syntactically valid construct that the
  selected API explicitly marks unsupported, but only if the reference
  distinguishes unsupported from invalid.
- **Determinism probe:** repeat the same valid-minimal fixture three times in
  each implemented surface and compare normalized semantic output; exclude
  timestamps, generated IDs, or ordering only when the governing text permits
  normalization.

If the sources do not define an invalid or unsupported contract, the product
must not invent one as GRAM behavior; a host-level validation state must be
clearly distinguished and cited to product policy.

### Baseline and recovery thresholds

| Signal | Current observed baseline | Predeclared threshold | Disconfirming/counterevidence |
| --- | --- | --- | --- |
| **Dissatisfier — no source-traceable executable GRAM behavior** | Zero retrieved source passages, zero source-verified API names, and zero demonstrated invocations in the evidence available to VOC. | One exact API name/signature plus dated citations to every applicable architecture, specification, and API-reference passage; one valid synthetic fixture completes one local shared-path invocation. | A URL alone, inferred name, mock bypass, uncited semantics, or host behavior represented as GRAM behavior fails. |
| **Satisfier — deterministic valid behavior** | Not demonstrated. | The same source-valid fixture run at least three times per implemented surface yields equivalent normalized semantic output with no network/private-data dependency. | Unexplained divergence, undocumented normalization, hidden state, or network/private-data use fails. |
| **Satisfier — explicit invalid/unsupported behavior** | Not demonstrated; sources not retrieved. | At least one source-supported negative fixture yields the documented distinguishable state in each implemented surface, or exact source evidence establishes that no such API-level state exists and the UI labels host validation separately. | Invented error categories, crash, hang, silent failure, or conflation of host and GRAM semantics fails. |
| **Satisfier — shared cross-surface contract** | Zero surfaces demonstrated. | Each authorized implemented surface invokes the same shared implementation and presents semantically equivalent result/status, subject to source-confirmed host feasibility. | Independent semantic reimplementations or a source architecture that prohibits the proposed sharing disconfirm the mechanism. |

These thresholds measure operational conformance and removal of a
documentation-only dissatisfier. They do not establish customer importance,
adoption, willingness to pay, or business viability.

### Counterevidence, limitations, and remaining blocker

- Owner intent and repeated contract language are not independent customer
  evidence.
- No participant, usage, telemetry, competitive, adoption, or payment evidence
  exists in this assignment.
- The smallest-looking API could require state, files, another API, or a host
  lifecycle that makes it unsuitable; only the three sources can resolve this.
- Cross-surface visibility may be owner-valued operational scope rather than a
  demonstrated user need.
- Public-source content, publication/update dates, version markers, section
  anchors, and contradictions were not observable in this runtime.

**Remaining blocker:** provide an HTTP-capable retrieval path in the authorized
runtime, or place owner-approved dated snapshots of exactly `GS-VOC-E08` through
`GS-VOC-E10` in the product workspace. Until then, the evidence cannot
responsibly contain the requested named invocable API, exact signature,
governing source semantics, or source-valid expected fixture results. The safe
state is **no API selected**, not an invented recommendation.

- **Artifact ID:** GS-VOC-EVID-001
- **Engagement contract:** `GS-ENG-001`
- **Work item:** `GS-FACTORY-LAUNCH-001`, bounded first value cycle only
- **Recorded:** 2026-10-09
- **Owner:** VOC agent `gramspec-voc`
- **Assignment acceptance:** **ACCEPTED.** The VOC accepts the bounded
  public-source inventory, outcome framing, and measurement assignment recorded
  in `GS-ENG-001`. This acceptance does not expand authority.
- **Authority and limits:** Human-owner invocation at
  `2026-10-09T23:28:57.093-04:00`. No external contact, private data, spending,
  deployment, publication, or release. No human subjects are involved;
  consent/notice is **Not applicable** because this artifact analyzes only
  repository-local records and is intended to inventory public technical
  references.
- **Participating-agent status:** The canonical contract records VOC,
  ProductOwner, Kanban, and Studio-Core Squad acceptance. This artifact makes no
  claim that pending Fullstacker or Factory acceptances have occurred.
- **Storage guidance:** `.github/instructions/artifact-storage.md` (status
  authoritative, established 2026-10-09). The approved destination is
  `docs/factories/gramspec-studio/evidence/`; there is no deviation.
- **Retention/privacy:** Retain with the product repository for its life. No
  credentials, private data, or participant identities are included.

## Decision and evidence coverage

**Decision to inform:** Which single invocable GRAM API can support the
smallest source-traceable, integrated first-cycle outcome, and what evidence
would show a meaningful improvement over baseline?

**Affected groups:** Future GRAM, VS Code, desktop, and web-UI users and product
maintainers. These groups were not contacted, observed, or represented as
participants.

**Coverage result:** The approved workspace identifies three intended public
sources by title—GRAM Architecture, GRAM Specification v1.1, and GRAM API
Reference—but the accessible owner invocation and repository-local records do
not contain their exact URLs, snapshots, publication owners, or contents.
Consequently, no named API, signature, semantics, error contract, or
architecture constraint can yet be source-verified. Product/customer demand
and willingness to pay are also untested.

## Evidence ledger

| ID | Source/location | Date | Method/segment | Observation | Interpretation | Limitation |
| --- | --- | --- | --- | --- | --- | --- |
| GS-VOC-E01 | `.github/instructions/artifact-storage.md`, “Sources and applicability” and “Authoritative destinations” | 2026-10-09 | Repository document review; product operations | The three references must be verified before executable scaffolding; Factory outcome evidence belongs in this directory. | Source verification is an explicit prerequisite, not optional documentation. | The record names but does not locate or reproduce the references. |
| GS-VOC-E02 | `docs/factories/gramspec-studio/engagement-contract.md`, “Storage and data handling” | 2026-10-09 | Repository document review; authorized inputs | Three public owner-supplied GRAM URLs are permitted inputs. | Public-source analysis is authorized. | The URLs themselves are absent from the accessible contract text. |
| GS-VOC-E03 | Same contract, “Launch objectives” and “Predeclared first-cycle value criteria” | 2026-10-09 | Repository document review; product operations | The intended increment exercises one ProductOwner-selected invocable GRAM API through a shared implementation and visible surfaces, with deterministic invocation and explicit unsupported/error behavior. | The smallest cycle should be a thin shared vertical slice, not disconnected shells. | This is an owner-approved operational target, not evidence of user demand or API feasibility. |
| GS-VOC-E04 | Workspace root and `docs/factories/gramspec-studio/` as inspected during this invocation | 2026-10-09 | Repository inventory | The accessible workspace contained storage guidance and the canonical contract; no product source, tests, reference snapshots, or prior outcome evidence were available to VOC. | The directly observed technical baseline is documentation-only. | Tool visibility is not proof that no unlisted or subsequently added artifact exists; recheck before delivery. |
| GS-VOC-E05 | Intended “GRAM Architecture” public source | Not available | Public technical-reference review | **Not observed:** exact source location/content was unavailable. | No architecture compatibility claim is supportable. | Blocks architecture citation and mechanism selection. |
| GS-VOC-E06 | Intended “GRAM Specification v1.1” public source | Version named; source date unavailable | Public technical-reference review | **Not observed:** exact source location/content was unavailable. | No conformance claim is supportable. | Blocks normative behavior and version-rule citation. |
| GS-VOC-E07 | Intended “GRAM API Reference” public source | Not available | Public technical-reference review | **Not observed:** exact source location/content was unavailable. | No particular API can be responsibly named or ranked. | Blocks signature, input/output, error, and invocation citations. |

No quotes from GRAM sources are recorded because those sources were not
available. Repository statements above are paraphrases, not customer quotes.

## Findings, counterevidence, and limitations

### Observations

1. The accepted operational outcome is an integrated, deterministic invocation
   of one source-traceable API, not completion of all APIs
   (`GS-VOC-E03`).
2. The directly observed baseline is a documentation-only workspace with no
   demonstrated GRAM invocation (`GS-VOC-E04`).
3. The evidence required to select a named API is missing from the accessible
   evidence packet (`GS-VOC-E05`–`GS-VOC-E07`).

### Interpretation

A stateless, deterministic, locally invocable API with small synthetic input
and inspectable output would likely minimize first-cycle integration and
privacy risk. This is a **selection heuristic**, not a finding about any actual
GRAM API.

### Counterevidence and negative cases

- The contract establishes owner intent, but it is not customer research and
  does not establish importance, recurrence, adoption, or willingness to pay.
- “Visible result in each surface” may enlarge the slice beyond the smallest
  technically feasible outcome; the references may impose a different host or
  lifecycle model.
- An apparently simple API may depend on runtime state, files, network access,
  or another API. That would disqualify it under the current local-only scope
  unless a source-supported synthetic adapter preserves its contract.
- Repeating the same contract requirement across records is not independent
  corroboration.

## Recommended first API and outcome

### API selection

**Named API: unresolved and blocked by missing source evidence.** Naming an API
now would fabricate a citation. The ProductOwner should select the first API
only after the three exact owner-supplied sources are accessible and the API
Reference confirms an invocable candidate.

Use this source-gated ranking rule:

1. explicitly invocable in the API Reference;
2. compatible with GRAM Architecture and Specification v1.1;
3. deterministic and stateless for a small synthetic fixture;
4. no network, credential, private-data, deployment, or paid dependency;
5. bounded input/output and documented unsupported/error behavior; and
6. reusable behind one shared contract across the authorized surfaces.

The first API satisfying every rule is the VOC recommendation; ties should be
decided by ProductOwner value priority and Squad feasibility. Evidence
citations must point to the exact architecture section, v1.1 normative clause,
and API Reference entry before the card becomes True Ready.

### Smallest first-cycle outcome hypothesis

> For a GRAM user trying to inspect one supported operation locally, a shared
> single-API invocation path helps obtain the same visible, deterministic
> result in the authorized VS Code, Electron, and web surfaces, compared with a
> documentation-only workspace or disconnected shells, because all surfaces
> use one source-conformant contract.

“GRAM user,” need importance, cross-surface value, and the differentiating
mechanism remain hypotheses. The only supported operational comparison is the
documentation-only baseline (`GS-VOC-E03`, `GS-VOC-E04`).

## Baseline and predeclared measures

| Signal | Baseline | First-cycle threshold | Failure/disconfirming signal |
| --- | --- | --- | --- |
| **Dissatisfier: no executable source-traceable behavior** | 0 source-verified APIs demonstrated; no executable product path observed (`GS-VOC-E04`) | Exactly 1 API has citations to all applicable governing source passages and completes one local end-to-end invocation through the shared path. | Missing/ambiguous citation, mocked success that bypasses the shared path, or no completed invocation. |
| **Satisfier: deterministic contract behavior** | Not demonstrated | The same fixed synthetic valid input, repeated at least 3 times per implemented surface, produces the same normalized result and no network access. | Any unexplained result divergence, nondeterminism, or network/private-data dependency. |
| **Satisfier: shared behavior across surfaces** | 0 surfaces demonstrated | VS Code, Electron, and web UI each invoke the same shared contract and visibly present equivalent normalized output; if source evidence proves a surface technically infeasible, the ProductOwner must accept the smallest equivalent before implementation. | A surface contains an independent reimplementation or yields semantically different output. |
| **Satisfier: clear unsupported/error behavior** | Not demonstrated | At least 1 source-valid success fixture and 1 documented invalid/unsupported fixture produce distinguishable, source-consistent result states in every implemented surface. | Crash, hang, silent failure, or invented error semantics. |
| **Satisfier: keyboard-operable local interaction** | Not demonstrated | The invocation and result can be reached and operated without a pointing device, with visible focus and a programmatically exposed result/status. | Pointer-only operation, lost focus, or result/status unavailable to accessibility semantics. |
| **Quality evidence** | No tests/build/demo observed | Automated shared-contract and integration tests, typecheck, and build pass; a dated local cumulative demo records each surface and criterion. | Any required check fails or evidence is absent. |

These are operational acceptance thresholds, not proof of customer value,
adoption, payment, or business viability. After the exact API is known, the
Squad and ProductOwner must reconcile technical thresholds with its normative
source contract without weakening the no-network/private-data limits.

## Blockers and smallest recovery

**Material blocker:** The exact three public source URLs or approved local
snapshots are absent from the accessible evidence packet. This blocks a
source-traceable named API recommendation and True Ready evidence; it does not
authorize external discovery, contact, or substitution with an unverified
source.

**Required recovery input:** Make the owner-supplied URLs or approved snapshots
available in the product workspace/contract-controlled handoff. VOC can then
inventory source IDs, versions/dates, normative status, candidate APIs,
dependencies, contradictions, and exact section citations. If access remains
unavailable, the safe result is “no API selected,” not an inferred API.

## Next human decision

After source access is restored, the ProductOwner—not VOC—must choose whether
the highest-ranked source-conformant API is the first-cycle product direction.
No additional value cycle, release, deployment, spending, private access, or
external research is implied.

## Recovery-panel availability

VOC is available during the current authorized runtime as the evidence
interpretation member of the required recovery panel for this blocker or a
first-cycle impasse. VOC can assess source traceability, counterevidence, and
outcome measures, but cannot decide product priority, board state, technical
feasibility, or waive a permission/quality gate.
