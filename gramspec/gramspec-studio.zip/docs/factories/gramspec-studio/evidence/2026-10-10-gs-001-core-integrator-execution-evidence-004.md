# GS-001 core integrator execution evidence (004)

- **Recorded:** 2026-10-10
- **Scope:** root configuration/manifests/lockfile and `src/shared-core/`
- **Ownership:** no Kanban, surface-owned, or hosted-product paths were
  changed.

## Preserved failing-first history

The preceding implementation evidence records that the requested pre-edit
commands were attempted but no npm process started because the execution
facility rejected delegation at maximum depth. Those records remain
authoritative; this record does not convert that blocker into a test result.

## Changes made

- Added the typed `GS-CORE-API/v1` `invokeGraph` implementation and verbatim
  synthetic fixture at `src/shared-core/index.ts`.
- Added strict root `tsconfig.json`.
- Added exact requested dev dependency declarations to `package.json` and a
  single root `package-lock.json` manifest.

The implementation validates projectName/projectId XOR before reading the
fixture, performs only the fixture-declared exact-value and SHA-256 integrity
checks, preserves graph bytes and role order, and produces stable local
rendering without network, credentials, environment, persistence, hosted
semantics, or general canonicalization.

## Command ledger

| Command | Result |
|---|---|
| `npm run test:core` (failing-first) | **Not executed:** no process-capable command route was available; no exit code or test output exists. |
| `npm run test:integration` (failing-first) | **Not executed:** same blocker; no exit code or test output exists. |
| exact dependency installation | **Not executed:** no process-capable command route was available; package installation and package-integrity verification are unclaimed. |
| `npm run test:core` (post-change) | Not executed. |
| `npm run test:integration` (post-change) | Not executed. |
| `npm run typecheck` | Not executed. |
| `npm run build` | Not executed. |

## Status and blockers

The implementation artifacts and interface exports are present, but empirical
verification is incomplete. No completion, passing test, installed dependency,
build, release, or deployment claim is made. A runtime that can execute local
npm processes is still required to install dependencies (and regenerate a
fully resolved lockfile if npm requires transitive entries), then run the
focused tests, typecheck, and build.
