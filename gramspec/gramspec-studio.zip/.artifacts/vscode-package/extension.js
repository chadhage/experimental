"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/vscode/extension.ts
var extension_exports = {};
__export(extension_exports, {
  SHOW_SELECTOR_REJECTION_COMMAND: () => SHOW_SELECTOR_REJECTION_COMMAND,
  SHOW_SYNTHETIC_GRAPH_COMMAND: () => SHOW_SYNTHETIC_GRAPH_COMMAND,
  activate: () => activate,
  deactivate: () => deactivate
});
module.exports = __toCommonJS(extension_exports);
var vscode = __toESM(require("vscode"), 1);

// src/shared-core/index.ts
var GS_CORE_API_VERSION = "GS-CORE-API/v1";
var GRAPH_JSON = '{\n  "factTypes": [{\n    "name": "SyntheticEnrollment",\n    "roles": ["student", "course"]\n  }]\n}';
var CANONICAL_JSON = '{"factTypes":[{"name":"SyntheticEnrollment","roles":["student","course"]}]}';
var CONTENT_HASH = "d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b";
var ETAG = '"synthetic-d19697a2a55ecbc37a6de5af416911d314a6e06019e80a522c75d229ed6b8d7b"';
var syntheticGraphFixture = Object.freeze({
  graphJson: GRAPH_JSON,
  canonicalJson: CANONICAL_JSON,
  contentHash: CONTENT_HASH,
  etag: ETAG
});
var invalidSelector = Object.freeze({
  ok: false,
  error: Object.freeze({
    code: "INVALID_SELECTOR",
    message: "Provide exactly one non-empty projectName or projectId."
  })
});
var invalidFixture = Object.freeze({
  ok: false,
  error: Object.freeze({
    code: "INVALID_FIXTURE",
    message: "Synthetic fixture failed its declared integrity contract."
  })
});
function hasValidSelector(request) {
  const hasName = typeof request.projectName === "string" && request.projectName.trim().length > 0;
  const hasId = typeof request.projectId === "string" && request.projectId.trim().length > 0;
  return hasName !== hasId;
}
function fixtureIsValid(value) {
  if (typeof value !== "object" || value === null) return false;
  const fixture = value;
  if (fixture.graphJson !== GRAPH_JSON || fixture.canonicalJson !== CANONICAL_JSON || fixture.contentHash !== CONTENT_HASH || fixture.etag !== ETAG) {
    return false;
  }
  const observedHash = sha256(fixture.canonicalJson);
  return observedHash === fixture.contentHash;
}
function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const bitLength = bytes.length * 8;
  const paddedLength = Math.ceil((bytes.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(bytes);
  padded[bytes.length] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 4, bitLength, false);
  const words = new Uint32Array(64);
  const hash = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  const constants = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  const rotateRight = (word, bits) => word >>> bits | word << 32 - bits;
  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const before15 = words[index - 15] ?? 0;
      const before2 = words[index - 2] ?? 0;
      const small0 = rotateRight(before15, 7) ^ rotateRight(before15, 18) ^ before15 >>> 3;
      const small1 = rotateRight(before2, 17) ^ rotateRight(before2, 19) ^ before2 >>> 10;
      words[index] = (words[index - 16] ?? 0) + small0 + (words[index - 7] ?? 0) + small1 >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = hash;
    for (let index = 0; index < 64; index += 1) {
      const big1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = e & f ^ ~e & g;
      const temporary1 = h + big1 + choice + (constants[index] ?? 0) + (words[index] ?? 0) >>> 0;
      const big0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = a & b ^ a & c ^ b & c;
      const temporary2 = big0 + majority >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temporary1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temporary1 + temporary2 >>> 0;
    }
    hash[0] = (hash[0] ?? 0) + a >>> 0;
    hash[1] = (hash[1] ?? 0) + b >>> 0;
    hash[2] = (hash[2] ?? 0) + c >>> 0;
    hash[3] = (hash[3] ?? 0) + d >>> 0;
    hash[4] = (hash[4] ?? 0) + e >>> 0;
    hash[5] = (hash[5] ?? 0) + f >>> 0;
    hash[6] = (hash[6] ?? 0) + g >>> 0;
    hash[7] = (hash[7] ?? 0) + h >>> 0;
  }
  return [...hash].map((word) => word.toString(16).padStart(8, "0")).join("");
}
function render(fixture) {
  return [
    GS_CORE_API_VERSION,
    "Synthetic local fixture (no live interoperability)",
    `graphJson=${fixture.graphJson}`,
    `canonicalJson=${fixture.canonicalJson}`,
    `contentHash=${fixture.contentHash}`,
    `ETag=${fixture.etag}`
  ].join("\n");
}
function invokeGraph(request, fixture = syntheticGraphFixture) {
  if (!hasValidSelector(request)) return invalidSelector;
  if (!fixtureIsValid(fixture)) return invalidFixture;
  return {
    ok: true,
    value: {
      apiVersion: GS_CORE_API_VERSION,
      graphJson: fixture.graphJson,
      canonicalJson: fixture.canonicalJson,
      contentHash: fixture.contentHash,
      etag: fixture.etag,
      renderText: render(fixture)
    }
  };
}

// src/vscode/adapter.ts
var SYNTHETIC_VSCODE_SELECTOR = Object.freeze({
  projectName: "synthetic-vscode-surface"
});
function getSyntheticGraphRenderText() {
  const result = invokeGraph(SYNTHETIC_VSCODE_SELECTOR);
  if (!result.ok) {
    throw new Error(result.error.message);
  }
  return result.value.renderText;
}
function getSelectorRejectionText() {
  const result = invokeGraph({});
  if (result.ok) {
    throw new Error("Expected the shared core to reject a missing selector.");
  }
  return result.error.message;
}

// src/vscode/extension.ts
var SHOW_SYNTHETIC_GRAPH_COMMAND = "gramspecStudio.showSyntheticGraph";
var SHOW_SELECTOR_REJECTION_COMMAND = "gramspecStudio.showSelectorRejection";
async function showText(content) {
  const document = await vscode.workspace.openTextDocument({
    content,
    language: "plaintext"
  });
  await vscode.window.showTextDocument(document, { preview: false });
  return content;
}
function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand(
      SHOW_SYNTHETIC_GRAPH_COMMAND,
      async () => showText(getSyntheticGraphRenderText())
    ),
    vscode.commands.registerCommand(
      SHOW_SELECTOR_REJECTION_COMMAND,
      async () => showText(getSelectorRejectionText())
    )
  );
}
function deactivate() {
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SHOW_SELECTOR_REJECTION_COMMAND,
  SHOW_SYNTHETIC_GRAPH_COMMAND,
  activate,
  deactivate
});
